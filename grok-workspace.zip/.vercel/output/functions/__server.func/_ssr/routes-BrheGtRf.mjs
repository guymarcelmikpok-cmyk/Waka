import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Radio, c as MapPin, d as Bike, i as Search, l as Car, o as Phone, r as Star, s as MessageSquare, t as X, u as CarFront } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BrheGtRf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PLACES = [
	{
		id: "marche",
		name: "Marché central",
		zone: "Centre-ville",
		lat: 4.5778,
		lng: 13.6846,
		hint: "Le départ le plus demandé",
		keywords: "centre ville marche bertoua"
	},
	{
		id: "hopital",
		name: "Hôpital régional",
		zone: "CENAJES",
		lat: 4.5744,
		lng: 13.6908,
		hint: "Carrefour CENAJES · dès 200 F",
		keywords: "hopital hospital cenajes sante"
	},
	{
		id: "ngaikada",
		name: "Ngaïkada",
		zone: "Centre-ville",
		lat: 4.5756,
		lng: 13.6806,
		hint: "Tout près du marché · 200 F",
		keywords: "ngaikada ngaikada"
	},
	{
		id: "enia",
		name: "Carrefour ENIA",
		zone: "ENIA",
		lat: 4.5802,
		lng: 13.6762,
		hint: "200 à 250 F en moto",
		keywords: "enia carrefour"
	},
	{
		id: "haoussa",
		name: "Quartier Haoussa",
		zone: "Haoussa",
		lat: 4.5832,
		lng: 13.6922,
		hint: "150 à 200 F depuis le centre",
		keywords: "haoussa haussa"
	},
	{
		id: "tindamda",
		name: "Tindamda",
		zone: "Tindamda",
		lat: 4.5852,
		lng: 13.6868,
		hint: "200 F depuis le centre",
		keywords: "tindamba tindamda"
	},
	{
		id: "toungou",
		name: "Toungou",
		zone: "Toungou",
		lat: 4.5872,
		lng: 13.6784,
		hint: "250 à 300 F",
		keywords: "toungou"
	},
	{
		id: "monou1",
		name: "Monou I",
		zone: "Haoussa",
		lat: 4.5864,
		lng: 13.6964,
		hint: "200 F",
		keywords: "monou 1"
	},
	{
		id: "monou2",
		name: "Monou II",
		zone: "Haoussa",
		lat: 4.5892,
		lng: 13.7016,
		hint: "250 à 300 F",
		keywords: "monou 2"
	},
	{
		id: "kano",
		name: "Kano",
		zone: "Kano",
		lat: 4.5702,
		lng: 13.6742,
		hint: "300 F en moto",
		keywords: "kano"
	},
	{
		id: "dubai",
		name: "Kano Traverse · Dubaï",
		zone: "Kano",
		lat: 4.5664,
		lng: 13.6684,
		hint: "IPPOL · 400 F",
		keywords: "dubai dubay ippol traverse"
	},
	{
		id: "touristique",
		name: "Touristique Express",
		zone: "Goliké",
		lat: 4.575,
		lng: 13.6727,
		hint: "Agences · rue Goliké Fabien",
		keywords: "bus gare agence voyage touristique golike"
	},
	{
		id: "mokolo",
		name: "Mokolo Dernier Poteau",
		zone: "Mokolo",
		lat: 4.5632,
		lng: 13.6808,
		hint: "200 à 300 F",
		keywords: "mokolo safari poteau"
	},
	{
		id: "mokolo4",
		name: "Mokolo 4",
		zone: "Mokolo",
		lat: 4.5584,
		lng: 13.6752,
		hint: "300 F",
		keywords: "mokolo 4"
	},
	{
		id: "tigaza",
		name: "Tigaza",
		zone: "Tigaza",
		lat: 4.5668,
		lng: 13.7052,
		hint: "200 F depuis le centre",
		keywords: "tigaza"
	},
	{
		id: "bertoua2",
		name: "Bertoua II",
		zone: "Bertoua II",
		lat: 4.5706,
		lng: 13.6982,
		hint: "Dès 200 F selon le coin",
		keywords: "bertoua 2 deuxieme"
	},
	{
		id: "nyonzengue",
		name: "Nyonzengue",
		zone: "Est",
		lat: 4.5766,
		lng: 13.7044,
		hint: "300 F",
		keywords: "nyonzengue"
	},
	{
		id: "nkolbikon",
		name: "Nkolbikon",
		zone: "Nkolbikon",
		lat: 4.5552,
		lng: 13.6904,
		hint: "Vers le sud de la ville",
		keywords: "nkolbikon npokolota"
	},
	{
		id: "concordia",
		name: "Carrefour Concordia",
		zone: "Nkolbikon",
		lat: 4.5506,
		lng: 13.6786,
		hint: "400 à 500 F",
		keywords: "concordia"
	},
	{
		id: "cub",
		name: "Communauté urbaine",
		zone: "Koumé",
		lat: 4.5844,
		lng: 13.6662,
		hint: "CUB · Martino · 400 à 500 F",
		keywords: "cub koume martino mairie"
	},
	{
		id: "bonis",
		name: "Carrefour Bonis",
		zone: "Bonis",
		lat: 4.593,
		lng: 13.6582,
		hint: "500 F",
		keywords: "bonis source"
	},
	{
		id: "mandjou",
		name: "Mandjou centre",
		zone: "Mandjou",
		lat: 4.568,
		lng: 13.792,
		hint: "Périurbain · dès 500 F en moto",
		keywords: "mandjou",
		far: true
	},
	{
		id: "aeroport",
		name: "Aéroport BTA",
		zone: "Aéroport",
		lat: 4.5411,
		lng: 13.7261,
		hint: "Voiture 2 000 à 6 000 F",
		keywords: "aeroport airport bta avion fkko",
		far: true
	}
];
/** Indicative daytime moto fares from the central market, in FCFA. */
var MOTO_FROM_MARKET = {
	hopital: 200,
	ngaikada: 200,
	enia: 250,
	haoussa: 200,
	tindamda: 200,
	toungou: 300,
	monou1: 200,
	monou2: 300,
	kano: 300,
	dubai: 400,
	touristique: 250,
	mokolo: 250,
	mokolo4: 300,
	tigaza: 200,
	bertoua2: 250,
	nyonzengue: 300,
	nkolbikon: 350,
	concordia: 500,
	cub: 450,
	bonis: 500,
	mandjou: 700,
	aeroport: 1500
};
var DRIVERS = [
	{
		id: "jp",
		name: "Jean-Pierre Owona",
		vehicle: "moto",
		tone: "warm",
		colorName: "rouge",
		plate: "ES 2144 A",
		rating: "4,8",
		trips: 1260,
		years: 9,
		langs: "français, gbaya",
		home: "marche",
		phone: "6XX XX 21 44"
	},
	{
		id: "sou",
		name: "Souleymane Bello",
		vehicle: "moto",
		tone: "warm",
		colorName: "jaune",
		plate: "ES 0881 B",
		rating: "4,9",
		trips: 2104,
		years: 14,
		langs: "français, fulfuldé",
		home: "haoussa",
		phone: "6XX XX 08 81"
	},
	{
		id: "pat",
		name: "Patrick Mbarga",
		vehicle: "moto",
		tone: "cool",
		colorName: "bleue",
		plate: "ES 3320 C",
		rating: "4,7",
		trips: 980,
		years: 6,
		langs: "français, maka",
		home: "mokolo",
		phone: "6XX XX 33 20"
	},
	{
		id: "cel",
		name: "Célestin Aboui",
		vehicle: "moto",
		tone: "cool",
		colorName: "verte",
		plate: "ES 1502 D",
		rating: "4,6",
		trips: 740,
		years: 4,
		langs: "français, gbaya",
		home: "kano",
		phone: "6XX XX 15 02"
	},
	{
		id: "rog",
		name: "Roger Mekong",
		vehicle: "moto",
		tone: "ink",
		colorName: "noire",
		plate: "ES 2766 E",
		rating: "4,8",
		trips: 1510,
		years: 11,
		langs: "français",
		home: "tigaza",
		phone: "6XX XX 27 66"
	},
	{
		id: "die",
		name: "Dieudonné Nkomo",
		vehicle: "taxi",
		tone: "warm",
		colorName: "jaune",
		plate: "ES 4418 T",
		rating: "4,8",
		trips: 860,
		years: 11,
		langs: "français",
		home: "touristique",
		phone: "6XX XX 44 18"
	},
	{
		id: "mar",
		name: "Martine Essomba",
		vehicle: "taxi",
		tone: "warm",
		colorName: "jaune",
		plate: "ES 2290 T",
		rating: "4,9",
		trips: 640,
		years: 8,
		langs: "français, maka",
		home: "hopital",
		phone: "6XX XX 22 90"
	},
	{
		id: "ib",
		name: "Ibrahim Amadou",
		vehicle: "taxi",
		tone: "ink",
		colorName: "blanche",
		plate: "ES 1176 T",
		rating: "4,7",
		trips: 510,
		years: 5,
		langs: "français, fulfuldé",
		home: "bertoua2",
		phone: "6XX XX 11 76"
	},
	{
		id: "ai",
		name: "Aïcha Nsangou",
		vehicle: "berline",
		tone: "ink",
		colorName: "grise",
		plate: "ES 7004 B",
		rating: "4,9",
		trips: 390,
		years: 7,
		langs: "français",
		home: "cub",
		phone: "6XX XX 70 04"
	},
	{
		id: "bl",
		name: "Blaise Ondoa",
		vehicle: "berline",
		tone: "cool",
		colorName: "noire",
		plate: "ES 6155 B",
		rating: "4,8",
		trips: 280,
		years: 10,
		langs: "français, gbaya",
		home: "enia",
		phone: "6XX XX 61 55"
	}
];
var VEHICLES = [
	{
		id: "moto",
		short: "Moto",
		label: "Moto-taxi",
		hint: "Le quotidien"
	},
	{
		id: "taxi",
		short: "Taxi",
		label: "Taxi jaune",
		hint: "Forfait en ville"
	},
	{
		id: "berline",
		short: "Berline",
		label: "Berline",
		hint: "Direct, bagages"
	}
];
var PAYMENTS = [
	{
		id: "cash",
		label: "Espèces",
		hint: "Au conducteur"
	},
	{
		id: "om",
		label: "Orange Money",
		hint: "#150#"
	},
	{
		id: "momo",
		label: "MTN MoMo",
		hint: "*126#"
	}
];
var NETS = {
	"2g": {
		id: "2g",
		label: "2G",
		blurb: "Texte seul. Ça passe quand la data rame.",
		requestKb: .8,
		pingKb: .15,
		pingMs: 4500,
		matchMs: 2400,
		detail: "min"
	},
	"3g": {
		id: "3g",
		label: "3G",
		blurb: "Fiche courte, toujours sans photo.",
		requestKb: 1.8,
		pingKb: .45,
		pingMs: 2800,
		matchMs: 1100,
		detail: "mid"
	},
	"4g": {
		id: "4g",
		label: "4G",
		blurb: "Fiche complète. Plus vif, plus lourd.",
		requestKb: 8.4,
		pingKb: 1.6,
		pingMs: 1600,
		matchMs: 480,
		detail: "full"
	}
};
var QUICK_IDS = [
	"hopital",
	"kano",
	"mokolo",
	"haoussa",
	"aeroport",
	"mandjou"
];
var USSD_PLACE_IDS = [
	"marche",
	"hopital",
	"enia",
	"kano",
	"haoussa",
	"mokolo",
	"tigaza",
	"mandjou",
	"aeroport"
];
var STORAGE_KEY = "waka-bertoua-v1";
function placeById(id) {
	const place = PLACES.find((item) => item.id === id);
	if (!place) throw new Error(`Quartier inconnu : ${id}`);
	return place;
}
function vehicleMeta(id) {
	const meta = VEHICLES.find((item) => item.id === id);
	if (!meta) throw new Error(id);
	return meta;
}
function payLabel(id) {
	return PAYMENTS.find((item) => item.id === id)?.label ?? id;
}
function fold(value) {
	return value.normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase();
}
function round50(value) {
	return Math.max(50, Math.round(value / 50) * 50);
}
function round1(value) {
	return Math.round(value * 10) / 10;
}
function haversine(a, b) {
	const radius = 6371;
	const dLat = (b.lat - a.lat) * Math.PI / 180;
	const dLng = (b.lng - a.lng) * Math.PI / 180;
	const lat1 = a.lat * Math.PI / 180;
	const lat2 = b.lat * Math.PI / 180;
	const h = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
	return 2 * radius * Math.asin(Math.min(1, Math.sqrt(h)));
}
function isNight(hour) {
	return hour >= 18 || hour < 6;
}
function motoClosed(hour) {
	return hour >= 0 && hour < 6;
}
function quote(from, to, vehicle, hour) {
	const km = haversine(from, to);
	const night = isNight(hour);
	const minutesFor = (perKm, base) => Math.max(4, Math.round(km * perKm + base));
	if (from.id === to.id || km < .08) return {
		price: 0,
		km: 0,
		minutes: 0,
		detail: "Même point",
		blocked: "Le départ et l’arrivée sont identiques."
	};
	if (vehicle === "moto" && motoClosed(hour)) return {
		price: 0,
		km,
		minutes: minutesFor(3.1, 3),
		detail: "Moto fermée",
		blocked: "Règle Waka : pas de moto entre minuit et 6 h. Un taxi reste disponible."
	};
	if (vehicle === "moto") {
		const day = (from.id === "marche" ? MOTO_FROM_MARKET[to.id] : void 0) ?? (to.id === "marche" ? MOTO_FROM_MARKET[from.id] : void 0) ?? (km < .4 ? 200 : Math.max(200, round50(140 + km * 155)));
		return {
			price: night ? round50(day * 1.25) : day,
			km,
			minutes: minutesFor(3.1, 3),
			detail: night ? "Moto · majoration de nuit" : "Moto · tarif indicatif de journée"
		};
	}
	if (vehicle === "taxi") {
		if (!from.far && !to.far && km <= 3.2) return {
			price: night ? 400 : 350,
			km,
			minutes: minutesFor(2.6, 4),
			detail: night ? "Taxi de ville · nuit, 400 F" : "Taxi de ville · jour, 350 F"
		};
		return {
			price: round50((night ? 1100 : 900) + km * 360),
			km,
			minutes: minutesFor(2.2, 4),
			detail: night ? "Taxi course · nuit" : "Taxi course, hors forfait court"
		};
	}
	return {
		price: round50((night ? 1600 : 1400) + km * 400),
		km,
		minutes: minutesFor(2, 5),
		detail: from.far || to.far ? "Berline · trajet direct hors centre" : night ? "Berline · nuit" : "Berline · trajet direct"
	};
}
function closestDriver(vehicle, pickup) {
	return DRIVERS.filter((driver) => driver.vehicle === vehicle).reduce((best, driver) => {
		const bestKm = haversine(placeById(best.home), pickup);
		const nextKm = haversine(placeById(driver.home), pickup);
		if (nextKm < bestKm - .01) return driver;
		if (Math.abs(nextKm - bestKm) <= .01 && driver.name < best.name) return driver;
		return best;
	});
}
function mapBounds(focus) {
	const points = [...PLACES.filter((place) => !place.far), ...focus];
	let minLat = Infinity;
	let maxLat = -Infinity;
	let minLng = Infinity;
	let maxLng = -Infinity;
	for (const point of points) {
		minLat = Math.min(minLat, point.lat);
		maxLat = Math.max(maxLat, point.lat);
		minLng = Math.min(minLng, point.lng);
		maxLng = Math.max(maxLng, point.lng);
	}
	const padLat = Math.max(.0035, (maxLat - minLat) * .16);
	const padLng = Math.max(.0035, (maxLng - minLng) * .16);
	return {
		minLat: minLat - padLat,
		maxLat: maxLat + padLat,
		minLng: minLng - padLng,
		maxLng: maxLng + padLng
	};
}
function project(point, bounds) {
	return {
		x: (point.lng - bounds.minLng) / (bounds.maxLng - bounds.minLng) * 100,
		y: (bounds.maxLat - point.lat) / (bounds.maxLat - bounds.minLat) * 100
	};
}
function fcfa(value) {
	return `${new Intl.NumberFormat("fr-FR").format(value)}\u00a0F`;
}
function formatKm(km) {
	if (km < 1) return `${Math.max(40, Math.round(km * 1e3 / 10) * 10)}\u00a0m`;
	return `${km.toFixed(1).replace(".", ",")}\u00a0km`;
}
function formatKo(kb) {
	return `${(kb < 10 ? (Math.round(kb * 10) / 10).toFixed(1) : String(Math.round(kb))).replace(".", ",")}\u00a0Ko`;
}
function bertouaNow(date = /* @__PURE__ */ new Date()) {
	return {
		hour: Number(new Intl.DateTimeFormat("en-GB", {
			timeZone: "Africa/Douala",
			hour: "numeric",
			hourCycle: "h23"
		}).format(date)),
		clock: new Intl.DateTimeFormat("fr-FR", {
			timeZone: "Africa/Douala",
			hour: "2-digit",
			minute: "2-digit"
		}).format(date)
	};
}
function formatWhen(timestamp) {
	return new Intl.DateTimeFormat("fr-FR", {
		timeZone: "Africa/Douala",
		day: "numeric",
		month: "short",
		hour: "2-digit",
		minute: "2-digit"
	}).format(new Date(timestamp));
}
function initials(name) {
	const parts = name.split(" ").filter(Boolean);
	return `${parts[0]?.[0] ?? "?"}${parts[1]?.[0] ?? ""}`.toUpperCase();
}
function isNetId(value) {
	return value === "2g" || value === "3g" || value === "4g";
}
function isPay(value) {
	return value === "cash" || value === "om" || value === "momo";
}
function loadPrefs() {
	const fallback = {
		net: "2g",
		pay: "cash",
		trips: []
	};
	if (typeof window === "undefined") return fallback;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return fallback;
		const parsed = JSON.parse(raw);
		return {
			net: isNetId(parsed.net) ? parsed.net : "2g",
			pay: isPay(parsed.pay) ? parsed.pay : "cash",
			trips: Array.isArray(parsed.trips) ? parsed.trips.slice(0, 30) : []
		};
	} catch {
		return fallback;
	}
}
function VehicleIcon({ id, className }) {
	const cls = className ?? "size-4";
	if (id === "moto") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bike, {
		className: cls,
		"aria-hidden": "true"
	});
	if (id === "taxi") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Car, {
		className: cls,
		"aria-hidden": "true"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CarFront, {
		className: cls,
		"aria-hidden": "true"
	});
}
function toneClass(tone) {
	if (tone === "warm") return "bg-laterite text-paper";
	if (tone === "cool") return "bg-forest text-paper";
	return "bg-ink text-paper";
}
function WakaApp() {
	const boot = (0, import_react.useRef)(loadPrefs());
	const now = (0, import_react.useRef)(bertouaNow());
	const [net, setNet] = (0, import_react.useState)(boot.current.net);
	const [pay, setPay] = (0, import_react.useState)(boot.current.pay);
	const [trips, setTrips] = (0, import_react.useState)(boot.current.trips);
	const [kb, setKb] = (0, import_react.useState)(1.2);
	const [hour] = (0, import_react.useState)(now.current.hour);
	const [clock] = (0, import_react.useState)(now.current.clock);
	const [ride, setRide] = (0, import_react.useState)("idle");
	const [sheet, setSheet] = (0, import_react.useState)("plan");
	const [pickFor, setPickFor] = (0, import_react.useState)("dropoff");
	const [query, setQuery] = (0, import_react.useState)("");
	const [pickupId, setPickupId] = (0, import_react.useState)("marche");
	const [dropoffId, setDropoffId] = (0, import_react.useState)(null);
	const [vehicle, setVehicle] = (0, import_react.useState)("moto");
	const [active, setActive] = (0, import_react.useState)(null);
	const [marker, setMarker] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)(null);
	const [ussdOpen, setUssdOpen] = (0, import_react.useState)(false);
	const savedId = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		localStorage.setItem(STORAGE_KEY, JSON.stringify({
			net,
			pay,
			trips
		}));
	}, [
		net,
		pay,
		trips
	]);
	const pickup = placeById(pickupId);
	const dropoff = dropoffId ? placeById(dropoffId) : null;
	const selectedQuote = dropoff ? quote(pickup, dropoff, vehicle, hour) : null;
	const night = isNight(hour);
	const spend = (amount) => {
		setKb((value) => round1(value + amount));
		setActive((current) => current ? {
			...current,
			spent: round1(current.spent + amount)
		} : current);
	};
	const requestRide = (next) => {
		const chosenVehicle = next?.vehicle ?? vehicle;
		const from = next?.pickup ?? pickup;
		const to = next?.dropoff ?? dropoff;
		const chosenPay = next?.pay ?? pay;
		if (!to) return;
		const priced = quote(from, to, chosenVehicle, hour);
		if (priced.blocked) {
			setNote(priced.blocked);
			return;
		}
		const driver = closestDriver(chosenVehicle, from);
		const spent = NETS[net].requestKb;
		setVehicle(chosenVehicle);
		setPickupId(from.id);
		setDropoffId(to.id);
		setPay(chosenPay);
		setNote(null);
		setSheet("plan");
		setUssdOpen(false);
		setMarker(placeById(driver.home));
		setKb((value) => round1(value + spent));
		setActive({
			id: `${Date.now()}`,
			pickup: from,
			dropoff: to,
			vehicle: chosenVehicle,
			price: priced.price,
			km: priced.km,
			minutes: priced.minutes,
			detail: priced.detail,
			driver,
			pay: chosenPay,
			spent
		});
		setRide("match");
	};
	const cancelRide = () => {
		setRide("idle");
		setActive(null);
		setMarker(null);
		setNote(null);
	};
	const newCourse = () => {
		setRide("idle");
		setActive(null);
		setMarker(null);
		setDropoffId(null);
		setNote(null);
		setSheet("plan");
	};
	(0, import_react.useEffect)(() => {
		if (ride !== "match" || !active) return;
		const timer = window.setTimeout(() => setRide("arrive"), NETS[net].matchMs);
		return () => window.clearTimeout(timer);
	}, [
		ride,
		net,
		active?.id
	]);
	(0, import_react.useEffect)(() => {
		if (ride !== "arrive" && ride !== "ride" || !active) return;
		const from = ride === "arrive" ? placeById(active.driver.home) : active.pickup;
		const to = ride === "arrive" ? active.pickup : active.dropoff;
		const distance = haversine(from, to);
		const ms = Math.min(9e3, Math.max(1800, distance * 2600));
		let stopped = false;
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const finish = () => {
			if (stopped) return;
			stopped = true;
			setMarker(to);
			setRide(ride === "arrive" ? "ride" : "done");
		};
		if (reduced) {
			const timer = window.setTimeout(finish, 500);
			return () => {
				stopped = true;
				window.clearTimeout(timer);
			};
		}
		const started = performance.now();
		let frame = 0;
		const tick = (nowMs) => {
			if (stopped) return;
			const t = Math.min(1, (nowMs - started) / ms);
			const eased = 1 - (1 - t) ** 2;
			setMarker({
				lat: from.lat + (to.lat - from.lat) * eased,
				lng: from.lng + (to.lng - from.lng) * eased
			});
			if (t < 1) frame = requestAnimationFrame(tick);
			else finish();
		};
		frame = requestAnimationFrame(tick);
		return () => {
			stopped = true;
			cancelAnimationFrame(frame);
		};
	}, [ride, active?.id]);
	(0, import_react.useEffect)(() => {
		if (ride !== "arrive" && ride !== "ride") return;
		const amount = NETS[net].pingKb;
		const timer = window.setInterval(() => {
			setKb((value) => round1(value + amount));
			setActive((current) => current ? {
				...current,
				spent: round1(current.spent + amount)
			} : current);
		}, NETS[net].pingMs);
		return () => window.clearInterval(timer);
	}, [ride, net]);
	(0, import_react.useEffect)(() => {
		if (ride !== "done" || !active) return;
		if (savedId.current === active.id) return;
		savedId.current = active.id;
		const spent = round1(active.spent + .2);
		const trip = {
			id: active.id,
			at: Date.now(),
			from: active.pickup.name,
			to: active.dropoff.name,
			vehicle: active.vehicle,
			price: active.price,
			pay: active.pay,
			km: active.km,
			driver: active.driver.name,
			spent
		};
		setTrips((current) => [trip, ...current.filter((item) => item.id !== trip.id)].slice(0, 30));
		setKb((value) => round1(value + .2));
		setActive((current) => current ? {
			...current,
			spent
		} : current);
	}, [ride, active?.id]);
	const focus = [pickup];
	if (dropoff) focus.push(dropoff);
	if (marker) focus.push({
		id: "live",
		name: "live",
		zone: "",
		lat: marker.lat,
		lng: marker.lng,
		hint: "",
		keywords: "",
		far: true
	});
	const bounds = mapBounds(focus);
	const liveTarget = active ? ride === "ride" || ride === "done" ? active.dropoff : active.pickup : null;
	const remaining = marker && liveTarget && (ride === "arrive" || ride === "ride") ? haversine(marker, liveTarget) : null;
	const openPick = (target) => {
		if (ride === "match" || ride === "arrive" || ride === "ride") return;
		setPickFor(target);
		setQuery("");
		setNote(null);
		setSheet("pick");
	};
	const choosePlace = (id) => {
		if (pickFor === "pickup") {
			setPickupId(id);
			if (id === dropoffId) setDropoffId(null);
		} else if (id === pickupId) {
			setNote("Choisissez un autre point que le départ.");
			return;
		} else setDropoffId(id);
		setNote(null);
		setQuery("");
		setSheet("plan");
	};
	const status = ride === "match" ? "Recherche d’un conducteur" : ride === "arrive" ? `${active?.driver.name ?? "Le conducteur"} approche` : ride === "ride" ? "Course en cours" : ride === "done" ? "Course terminée" : "Prêt à réserver";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-sand text-ink lg:h-dvh lg:overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 shrink-0 bg-forest" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "z-20 flex shrink-0 items-center justify-between gap-3 bg-sand px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl leading-none font-semibold text-forest",
							children: "Waka"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-xs font-semibold tracking-widest text-muted uppercase",
							children: "Bertoua"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							clock,
							" · ",
							night ? "nuit" : "jour",
							" · ",
							formatKo(kb)
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-end gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						role: "radiogroup",
						"aria-label": "Réseau",
						className: "flex rounded-full border border-line bg-paper p-1",
						children: Object.keys(NETS).map((id) => {
							const on = net === id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								role: "radio",
								"aria-checked": on,
								onClick: () => setNet(id),
								className: `press h-8 min-w-10 rounded-full px-2.5 text-xs font-semibold ${on ? "bg-forest text-paper" : "text-muted"}`,
								children: NETS[id].label
							}, id);
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setUssdOpen(true),
							className: "inline-flex h-6 items-center gap-1 text-xs font-semibold text-forest",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, {
								className: "size-3.5",
								"aria-hidden": "true"
							}), "*214#"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSheet("history"),
							className: "h-6 text-xs font-semibold text-muted",
							children: "Reçus"
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col lg:min-h-0 lg:grid lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative h-72 overflow-hidden lg:col-span-2 lg:h-auto lg:min-h-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CityMap, {
						bounds,
						pickupId: active?.pickup.id ?? pickupId,
						dropoffId: active?.dropoff.id ?? dropoffId,
						marker,
						driver: active?.driver ?? null,
						onPick: (id) => {
							if (ride === "match" || ride === "arrive" || ride === "ride") return;
							if (id === pickupId) return;
							setDropoffId(id);
							setSheet("plan");
							setNote(null);
						}
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative z-10 -mt-5 flex-1 rounded-t-3xl border border-line bg-sand px-4 pt-5 pb-8 lg:col-span-1 lg:mt-0 lg:overflow-y-auto lg:rounded-none lg:border-y-0 lg:border-r-0 lg:border-l lg:pb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "sr-only",
						"aria-live": "polite",
						children: status
					}), sheet === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryPanel, {
						trips,
						onBack: () => setSheet("plan"),
						live: ride === "match" || ride === "arrive" || ride === "ride"
					}) : sheet === "pick" && ride !== "match" && ride !== "arrive" && ride !== "ride" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PickPanel, {
						target: pickFor,
						query,
						onQuery: setQuery,
						onBack: () => setSheet("plan"),
						onChoose: choosePlace
					}) : ride === "match" && active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchPanel, {
						net,
						active,
						onCancel: cancelRide
					}) : (ride === "arrive" || ride === "ride") && active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LivePanel, {
						ride,
						active,
						net,
						remaining,
						note,
						onCancel: cancelRide,
						onCall: () => setNote(`Appel vers ${active.driver.phone}. En 2G la voix passe encore si la data coupe. Signalisation 0,2 Ko.`),
						onSms: () => {
							spend(.2);
							setNote("SMS parti vers le conducteur. 0,2 Ko.");
						}
					}) : ride === "done" && active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonePanel, {
						active,
						onNew: newCourse,
						onHistory: () => setSheet("history")
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanPanel, {
						net,
						hour,
						night,
						pickup,
						dropoff,
						vehicle,
						pay,
						quote: selectedQuote,
						note,
						onPick: openPick,
						onQuick: (id) => {
							if (id === pickupId) {
								setNote("Ce point est déjà le départ.");
								return;
							}
							setDropoffId(id);
							setNote(null);
						},
						onVehicle: setVehicle,
						onPay: setPay,
						onRequest: () => requestRide()
					})]
				})]
			}),
			ussdOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ussd, {
				net,
				hour,
				trips,
				onClose: () => setUssdOpen(false),
				onNet: setNet,
				onBook: (from, to, chosen) => requestRide({
					pickup: from,
					dropoff: to,
					vehicle: chosen
				})
			}) : null
		]
	});
}
function CityMap({ bounds, pickupId, dropoffId, marker, driver, onPick }) {
	const visible = PLACES.filter((place) => {
		if (!place.far) return true;
		return place.id === pickupId || place.id === dropoffId;
	});
	const driverPoint = marker ? project(marker, bounds) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "map-field relative h-full min-h-72 w-full",
		children: [
			visible.map((place) => {
				const point = project(place, bounds);
				const role = place.id === pickupId ? "départ" : place.id === dropoffId ? "arrivée" : "quartier";
				const selected = place.id === pickupId || place.id === dropoffId;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `${place.name}, ${role}`,
					onClick: () => onPick(place.id),
					className: "absolute z-10 flex size-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center",
					style: {
						left: `${point.x}%`,
						top: `${point.y}%`
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex flex-col items-center",
						children: [selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-1 rounded-full border border-line bg-paper px-2 py-0.5 text-xs font-medium whitespace-nowrap text-ink",
							children: place.name
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `block rounded-full border-2 border-paper ${place.id === dropoffId ? "size-5 bg-laterite" : place.id === pickupId ? "size-5 bg-forest" : "size-3.5 bg-forest-deep"}` })]
					})
				}, place.id);
			}),
			driverPoint && driver ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute z-20 -translate-x-1/2 -translate-y-1/2",
				style: {
					left: `${driverPoint.x}%`,
					top: `${driverPoint.y}%`
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "relative flex size-11 items-center justify-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pulse-ring absolute inset-0 rounded-full bg-forest" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `relative flex size-11 items-center justify-center rounded-full border-2 border-paper ${toneClass(driver.tone)}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleIcon, {
							id: driver.vehicle,
							className: "size-5"
						})
					})]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-x-0 bottom-6 flex items-end justify-between px-4 lg:bottom-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-full bg-paper/90 px-3 py-1 text-xs font-medium text-forest-deep",
					children: "Carte locale · sans tuiles"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden rounded-full bg-paper/90 px-3 py-1 text-xs text-muted sm:block",
					children: "Vert départ · ocre arrivée"
				})]
			})
		]
	});
}
function PlanPanel({ net, hour, night, pickup, dropoff, vehicle, pay, quote: priced, note, onPick, onQuick, onVehicle, onPay, onRequest }) {
	const spec = NETS[net];
	const blocked = priced?.blocked;
	const label = !dropoff ? "Choisir une arrivée" : blocked ? "Moto indisponible" : `Demander · ${fcfa(priced?.price ?? 0)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl leading-tight font-semibold text-ink",
			children: "Où va-t-on ?"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-sm text-muted",
			children: [
				spec.blurb,
				" Demande ",
				formatKo(spec.requestKb),
				". Les quartiers sont déjà dans le téléphone."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceField, {
				label: "Départ",
				value: pickup.name,
				mark: "bg-forest",
				onClick: () => onPick("pickup")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceField, {
				label: "Arrivée",
				value: dropoff?.name ?? "Choisir un quartier",
				mark: dropoff ? "bg-laterite" : "bg-line",
				muted: !dropoff,
				onClick: () => onPick("dropoff")
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "scroll-x mt-3 flex gap-2 pb-1",
			children: QUICK_IDS.map((id) => {
				const place = placeById(id);
				const on = dropoff?.id === id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => onQuick(id),
					className: `press h-10 shrink-0 rounded-full border px-3 text-sm font-medium ${on ? "border-forest bg-foam text-forest-deep" : "border-line bg-paper text-ink"}`,
					children: place.name.replace(" Dernier Poteau", "").replace("Carrefour ", "")
				}, id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid grid-cols-3 gap-2",
			role: "radiogroup",
			"aria-label": "Véhicule",
			children: VEHICLES.map((item) => {
				const on = vehicle === item.id;
				const sample = dropoff ? quote(pickup, dropoff, item.id, hour) : null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "radio",
					"aria-checked": on,
					onClick: () => onVehicle(item.id),
					className: `press flex min-h-24 flex-col items-start justify-between rounded-2xl border px-3 py-3 text-left ${on ? "border-forest bg-foam" : "border-line bg-paper"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleIcon, {
						id: item.id,
						className: on ? "size-4 text-forest" : "size-4 text-muted"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-semibold",
						children: item.short
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-muted",
						children: sample?.blocked ? "Fermée" : sample ? fcfa(sample.price) : item.hint
					})] })]
				}, item.id);
			})
		}),
		priced && !priced.blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-sm text-muted",
			children: [
				priced.detail,
				" · ",
				formatKm(priced.km),
				" · environ ",
				priced.minutes,
				" min sur la route",
				night ? " · tarif de nuit" : ""
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 flex flex-wrap gap-2",
			role: "radiogroup",
			"aria-label": "Paiement",
			children: PAYMENTS.map((item) => {
				const on = pay === item.id;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "radio",
					"aria-checked": on,
					onClick: () => onPay(item.id),
					className: `press min-h-10 rounded-full border px-3 py-2 text-sm font-medium ${on ? "border-forest bg-forest text-paper" : "border-line bg-paper text-ink"}`,
					children: [item.label, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: on ? "text-paper/80" : "text-muted",
						children: [" · ", item.hint]
					})]
				}, item.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			disabled: !dropoff || Boolean(blocked),
			onClick: onRequest,
			className: "press mt-4 flex h-14 w-full items-center justify-center rounded-2xl bg-forest text-base font-semibold text-paper disabled:opacity-40",
			children: label
		}),
		note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 rounded-2xl bg-clay px-3 py-2 text-sm text-ink",
			children: note
		}) : null,
		blocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 rounded-2xl bg-clay px-3 py-2 text-sm text-ink",
			children: blocked
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "mt-5 rounded-2xl bg-paper px-4 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold text-ink",
				children: "Face à Yango, à Bertoua"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Yango est taillé pour une grande ville et une carte lourde. Ici, la plupart des trajets se font en moto, souvent en espèces, parfois avec une seule barre. Waka fixe le prix avant de partir, garde Kano, Mokolo, l’hôpital et Mandjou dans le téléphone, et bascule sur le *214# si l’écran ne charge plus."
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-xs text-muted",
			children: "Tarifs indicatifs de journée, arrondis à 50 F. Le taxi court suit le repère local : 350 F le jour, 400 F la nuit. Démo : aucun paiement réel."
		}),
		hour >= 0 && hour < 6 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-muted",
			children: "Entre minuit et 6 h, Waka ne propose que le taxi ou la berline."
		}) : null
	] });
}
function PlaceField({ label, value, mark, muted, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "press flex h-14 w-full items-center gap-3 rounded-2xl border border-line bg-paper px-3 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2.5 shrink-0 rounded-full ${mark}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `block truncate font-medium ${muted ? "text-muted" : "text-ink"}`,
				children: value
			})]
		})]
	});
}
function PickPanel({ target, query, onQuery, onBack, onChoose }) {
	const filtered = PLACES.filter((place) => {
		if (!query.trim()) return true;
		return fold(`${place.name} ${place.zone} ${place.hint} ${place.keywords}`).includes(fold(query.trim()));
	});
	const groups = [];
	for (const place of filtered) {
		const group = groups.find((item) => item.zone === place.zone);
		if (group) group.places.push(place);
		else groups.push({
			zone: place.zone,
			places: [place]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-semibold",
				children: target === "pickup" ? "Point de départ" : "Arrivée"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onBack,
				className: "text-sm font-semibold text-forest",
				children: "Fermer"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mt-3 flex h-12 items-center gap-2 rounded-2xl border border-line bg-paper px-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				className: "size-4 text-muted",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: query,
				onChange: (event) => onQuery(event.target.value),
				placeholder: "Kano, hôpital, Mandjou…",
				className: "h-full w-full bg-transparent text-base text-ink outline-none placeholder:text-muted"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-muted",
			children: "Recherche locale. 0 Ko."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2",
			children: groups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "py-6 text-sm text-muted",
				children: [
					"Aucun quartier pour « ",
					query,
					" »."
				]
			}) : groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-muted uppercase",
					children: group.zone
				}), group.places.map((place) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => onChoose(place.id),
					className: "flex min-h-14 w-full items-center gap-3 border-b border-line py-2 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-10 shrink-0 items-center justify-center rounded-full bg-foam text-forest",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
							className: "size-4",
							"aria-hidden": "true"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate font-medium",
							children: place.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm text-muted",
							children: place.hint
						})]
					})]
				}, place.id))]
			}, group.zone))
		})
	] });
}
function MatchPanel({ net, active, onCancel }) {
	const spec = NETS[net];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold text-forest",
			children: "Recherche"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "mt-1 font-display text-3xl leading-tight font-semibold",
			children: [
				"Un ",
				vehicleMeta(active.vehicle).short.toLowerCase(),
				" en ",
				spec.label
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-sm text-muted",
			children: [
				active.pickup.name,
				" vers ",
				active.dropoff.name,
				". ",
				spec.blurb,
				" Cette demande : ",
				formatKo(active.spent),
				"."
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 h-1.5 overflow-hidden rounded-full bg-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bar-slide h-full w-1/3 rounded-full bg-forest" })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onCancel,
			className: "press mt-6 flex h-12 w-full items-center justify-center rounded-2xl border border-line bg-paper font-semibold",
			children: "Annuler"
		})
	] });
}
function LivePanel({ ride, active, net, remaining, note, onCancel, onCall, onSms }) {
	const detail = NETS[net].detail;
	const progress = ride === "ride" ? Math.max(8, Math.min(100, Math.round((1 - (remaining ?? 0) / Math.max(active.km, .05)) * 100))) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold text-forest",
			children: ride === "arrive" ? "En approche" : "En course"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-1 font-display text-3xl leading-tight font-semibold",
			children: ride === "arrive" ? active.driver.name.split(" ")[0] : active.dropoff.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: ride === "arrive" ? remaining !== null && remaining < .12 ? "Déjà au point de départ · suivi accéléré" : `${remaining !== null ? formatKm(remaining) : "—"} du départ · suivi accéléré` : `${remaining !== null ? formatKm(remaining) : "—"} restants · prix fixé`
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DriverCard, {
			driver: active.driver,
			vehicle: active.vehicle,
			detail
		}),
		ride === "ride" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 h-2 overflow-hidden rounded-full bg-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full rounded-full bg-forest",
				style: { width: `${progress}%` }
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 font-display text-3xl font-semibold text-forest-deep",
			children: fcfa(active.price)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-muted",
			children: [
				payLabel(active.pay),
				" · ",
				formatKm(active.km),
				" · ",
				active.detail
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-1 text-xs text-muted",
			children: [
				"Données de la course ",
				formatKo(active.spent),
				" · réseau ",
				NETS[net].label
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 grid grid-cols-2 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onCall,
				className: "press flex h-12 items-center justify-center gap-2 rounded-2xl border border-line bg-paper text-sm font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
					className: "size-4",
					"aria-hidden": "true"
				}), "Appeler"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onSms,
				className: "press flex h-12 items-center justify-center gap-2 rounded-2xl border border-line bg-paper text-sm font-semibold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, {
					className: "size-4",
					"aria-hidden": "true"
				}), "SMS"]
			})]
		}),
		note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 rounded-2xl bg-foam px-3 py-2 text-sm text-forest-deep",
			children: note
		}) : null,
		ride === "arrive" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onCancel,
			className: "press mt-3 flex h-12 w-full items-center justify-center rounded-2xl text-sm font-semibold text-muted",
			children: "Annuler la course"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-3 text-xs text-muted",
			children: [
				"Durée estimée sur la route : ",
				active.minutes,
				" min. L’aperçu est accéléré."
			]
		})
	] });
}
function DriverCard({ driver, vehicle, detail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mt-4 flex gap-3 rounded-2xl border border-line bg-paper p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `flex size-14 shrink-0 items-center justify-center rounded-full font-display text-xl ${toneClass(driver.tone)}`,
			children: initials(driver.name)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-semibold",
					children: driver.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						vehicleMeta(vehicle).label,
						" ",
						driver.colorName
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 inline-flex rounded-md border border-ink px-2 py-0.5 text-xs font-semibold tracking-widest",
					children: driver.plate
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 flex items-center gap-1 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
							className: "size-3.5 fill-laterite text-laterite",
							"aria-hidden": "true"
						}),
						driver.rating,
						detail !== "min" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [
								"· ",
								driver.trips,
								" courses"
							]
						}) : null
					]
				}),
				detail === "full" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						driver.years,
						" ans · ",
						driver.langs
					]
				}) : null
			]
		})]
	});
}
function DonePanel({ active, onNew, onHistory }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold text-forest",
			children: "Course terminée"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-1 font-display text-4xl font-semibold text-forest-deep",
			children: fcfa(active.price)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "mt-4 rounded-2xl border border-dashed border-line bg-paper p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-muted uppercase",
					children: "Reçu Waka"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 font-medium",
					children: [
						active.pickup.name,
						" → ",
						active.dropoff.name
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						vehicleMeta(active.vehicle).label,
						" · ",
						active.driver.name
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						formatKm(active.km),
						" · ",
						payLabel(active.pay),
						" · ",
						active.driver.plate
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm text-muted",
					children: [
						"SMS de reçu envoyé · données de la course ",
						formatKo(active.spent),
						"."
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onNew,
			className: "press mt-4 flex h-14 w-full items-center justify-center rounded-2xl bg-forest text-base font-semibold text-paper",
			children: "Nouvelle course"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onHistory,
			className: "mt-2 h-11 w-full text-sm font-semibold text-forest",
			children: "Voir les reçus"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-muted",
			children: "Démo. Aucun Mobile Money n’a été débité."
		})
	] });
}
function HistoryPanel({ trips, onBack, live }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl font-semibold",
			children: "Reçus"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onBack,
			className: "text-sm font-semibold text-forest",
			children: live ? "Course en cours" : "Retour"
		})]
	}), trips.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-4 text-sm text-muted",
		children: "Aucune course pour l’instant. Du marché à Kano, la moto tourne souvent autour de 300 F."
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-3",
		children: trips.map((trip) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "border-b border-line py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "min-w-0 truncate font-medium",
						children: [
							trip.from,
							" → ",
							trip.to
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "shrink-0 font-semibold text-forest-deep",
						children: fcfa(trip.price)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						vehicleMeta(trip.vehicle).short,
						" · ",
						trip.driver,
						" · ",
						payLabel(trip.pay)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [
						formatWhen(trip.at),
						" · ",
						formatKm(trip.km),
						" · ",
						formatKo(trip.spent)
					]
				})
			]
		}, trip.id))
	})] });
}
function Ussd({ net, hour, trips, onClose, onNet, onBook }) {
	const [step, setStep] = (0, import_react.useState)("home");
	const [digit, setDigit] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [vehicle, setVehicle] = (0, import_react.useState)("moto");
	const [fromId, setFromId] = (0, import_react.useState)(null);
	const [toId, setToId] = (0, import_react.useState)(null);
	const places = USSD_PLACE_IDS.map((id) => placeById(id));
	const handle = (raw) => {
		const choice = raw.trim();
		setError(null);
		if (choice === "0" && step !== "home") {
			setStep({
				home: "home",
				vehicle: "home",
				from: "vehicle",
				to: "from",
				confirm: "to",
				receipts: "home"
			}[step]);
			return;
		}
		if (step === "home") {
			if (choice === "1") setStep("vehicle");
			else if (choice === "2") setStep("receipts");
			else if (choice === "3") {
				const order = [
					"2g",
					"3g",
					"4g"
				];
				const next = order[(order.indexOf(net) + 1) % order.length] ?? "2g";
				onNet(next);
				setError(`Réseau passé en ${NETS[next].label}.`);
			} else setError("Choix invalide.");
			return;
		}
		if (step === "vehicle") {
			const chosen = {
				"1": "moto",
				"2": "taxi",
				"3": "berline"
			}[choice];
			if (!chosen) {
				setError("Choix invalide.");
				return;
			}
			setVehicle(chosen);
			setStep("from");
			return;
		}
		if (step === "from" || step === "to") {
			const index = Number(choice) - 1;
			const place = places[index];
			if (!place) {
				setError("Numéro inconnu.");
				return;
			}
			if (step === "from") {
				setFromId(place.id);
				setStep("to");
			} else {
				if (place.id === fromId) {
					setError("Même point. Choisissez une autre arrivée.");
					return;
				}
				setToId(place.id);
				setStep("confirm");
			}
			return;
		}
		if (step === "confirm") {
			if (choice !== "1") {
				if (choice === "2") setStep("home");
				else setError("1 pour confirmer, 2 pour annuler.");
				return;
			}
			if (!fromId || !toId) return;
			const from = placeById(fromId);
			const to = placeById(toId);
			const priced = quote(from, to, vehicle, hour);
			if (priced.blocked) {
				setError(priced.blocked);
				return;
			}
			onBook(from, to, vehicle);
		}
	};
	const onSubmit = (event) => {
		event.preventDefault();
		handle(digit);
		setDigit("");
	};
	const lines = ussdLines(step, places, vehicle, fromId, toId, hour, trips, net);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-30 flex items-end justify-center bg-ink/50 p-3 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex max-h-[90dvh] w-full max-w-sm flex-col overflow-hidden rounded-3xl border border-forest bg-forest-deep text-paper",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-4 pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl font-semibold",
						children: "Waka · *214#"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-paper/70",
						children: [
							"Canal USSD · ",
							NETS[net].label,
							" · session légère"
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						"aria-label": "Fermer le canal USSD",
						className: "flex size-11 items-center justify-center rounded-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex-1 overflow-y-auto px-4 pb-3 text-sm leading-relaxed",
					children: [
						lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: line }, line)),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-clay",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs text-paper/70",
							children: "*214# ne remplace pas le *126# MoMo ni le #150# Orange. 0 revient en arrière."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "flex gap-2 border-t border-paper/20 p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: digit,
						onChange: (event) => setDigit(event.target.value),
						inputMode: "numeric",
						"aria-label": "Réponse USSD",
						placeholder: "Numéro",
						className: "h-12 min-w-0 flex-1 rounded-xl bg-paper/10 px-3 text-base text-paper outline-none placeholder:text-paper/50"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "press h-12 rounded-xl bg-laterite px-4 font-semibold text-ink",
						children: "Envoyer"
					})]
				})
			]
		})
	});
}
function ussdLines(step, places, vehicle, fromId, toId, hour, trips, net) {
	if (step === "home") return [
		"Waka Bertoua",
		`Reseau ${NETS[net].label}`,
		"",
		"1 Course",
		"2 Mes courses",
		"3 Changer de reseau"
	];
	if (step === "receipts") {
		if (trips.length === 0) return [
			"Aucune course.",
			"",
			"0 Retour"
		];
		return [
			"Dernieres courses",
			...trips.slice(0, 4).map((trip) => `${trip.from} - ${trip.to} : ${fcfa(trip.price)}`),
			"",
			"0 Retour"
		];
	}
	if (step === "vehicle") return [
		"Vehicule",
		"1 Moto",
		"2 Taxi jaune",
		"3 Berline",
		"",
		"0 Retour"
	];
	if (step === "from" || step === "to") return [
		step === "from" ? "Depart" : "Arrivee",
		...places.map((place, index) => `${index + 1} ${place.name}`),
		"",
		"0 Retour"
	];
	const from = fromId ? placeById(fromId) : null;
	const to = toId ? placeById(toId) : null;
	if (!from || !to) return ["Course incomplete", "0 Retour"];
	const priced = quote(from, to, vehicle, hour);
	if (priced.blocked) return [
		priced.blocked,
		"",
		"0 Retour"
	];
	return [
		"Confirmer",
		`${vehicleMeta(vehicle).label}`,
		`${from.name}`,
		`vers ${to.name}`,
		`${fcfa(priced.price)} · ${formatKm(priced.km)}`,
		`${priced.minutes} min sur la route`,
		"",
		"1 Oui",
		"2 Annuler",
		"0 Retour"
	];
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Boot, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WakaApp, {});
}
function Boot() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col bg-sand text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1 bg-forest" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-4 pt-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl font-semibold text-forest",
				children: "Waka"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Bertoua · le VTC qui tient en 2G"
			})]
		})]
	});
}
//#endregion
export { Home as component };
