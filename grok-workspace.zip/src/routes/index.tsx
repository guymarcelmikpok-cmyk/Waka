import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { WakaApp } from "@/components/waka/WakaApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  if (!ready) return <Boot />;
  return <WakaApp />;
}

function Boot() {
  return (
    <main className="flex min-h-dvh flex-col bg-sand text-ink">
      <div className="h-1 bg-forest" />
      <div className="px-4 pt-5">
        <p className="font-display text-2xl font-semibold text-forest">Waka</p>
        <p className="mt-1 text-sm text-muted">Bertoua · le VTC qui tient en 2G</p>
      </div>
    </main>
  );
}
