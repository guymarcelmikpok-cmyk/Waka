import {
  DRIVERS,
  MOTO_FROM_MARKET,
  PAYMENTS,
  PLACES,
  VEHICLES,
  type Driver,
  type NetId,
  type Pay,
  type Place,
  type Vehicle,
} from "./data";

export type LatLng = { lat: number; lng: number };

export type Bounds = {
  minLat: number;
  maxLat: number;
  minLng: number;
  maxLng: number;
};

export type Quote = {
  price: number;
  km: number;
  minutes: number;
  detail: string;
  blocked?: string;
};

export type SavedTrip = {
  id: string;
  at: number;
  from: string;
  to: string;
  vehicle: Vehicle;
  price: number;
  pay: Pay;
  km: number;
  driver: string;
  spent: number;
};

export function placeById(id: string): Place {
  const place = PLACES.find((item) => item.id === id);
  if (!place) throw new Error(`Quartier inconnu : ${id}`);
  return place;
}

export function vehicleMeta(id: Vehicle) {
  const meta = VEHICLES.find((item) => item.id === id);
  if (!meta) throw new Error(id);
  return meta;
}

export function payLabel(id: Pay): string {
  return PAYMENTS.find((item) => item.id === id)?.label ?? id;
}

export function fold(value: string): string {
  return value
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase();
}

export function round50(value: number): number {
  return Math.max(50, Math.round(value / 50) * 50);
}

export function round1(value: number): number {
  return Math.round(value * 10) / 10;
}

export function haversine(a: LatLng, b: LatLng): number {
  const radius = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const lat1 = (a.lat * Math.PI) / 180;
  const lat2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * radius * Math.asin(Math.min(1, Math.sqrt(h)));
}

export function isNight(hour: number): boolean {
  return hour >= 18 || hour < 6;
}

export function motoClosed(hour: number): boolean {
  return hour >= 0 && hour < 6;
}

export function quote(from: Place, to: Place, vehicle: Vehicle, hour: number): Quote {
  const km = haversine(from, to);
  const night = isNight(hour);
  const minutesFor = (perKm: number, base: number) =>
    Math.max(4, Math.round(km * perKm + base));

  if (from.id === to.id || km < 0.08) {
    return {
      price: 0,
      km: 0,
      minutes: 0,
      detail: "Même point",
      blocked: "Le départ et l’arrivée sont identiques.",
    };
  }

  if (vehicle === "moto" && motoClosed(hour)) {
    return {
      price: 0,
      km,
      minutes: minutesFor(3.1, 3),
      detail: "Moto fermée",
      blocked: "Règle Waka : pas de moto entre minuit et 6 h. Un taxi reste disponible.",
    };
  }

  if (vehicle === "moto") {
    const anchored =
      (from.id === "marche" ? MOTO_FROM_MARKET[to.id] : undefined) ??
      (to.id === "marche" ? MOTO_FROM_MARKET[from.id] : undefined);
    const day = anchored ?? (km < 0.4 ? 200 : Math.max(200, round50(140 + km * 155)));
    const price = night ? round50(day * 1.25) : day;
    return {
      price,
      km,
      minutes: minutesFor(3.1, 3),
      detail: night ? "Moto · majoration de nuit" : "Moto · tarif indicatif de journée",
    };
  }

  if (vehicle === "taxi") {
    const intra = !from.far && !to.far && km <= 3.2;
    if (intra) {
      return {
        price: night ? 400 : 350,
        km,
        minutes: minutesFor(2.6, 4),
        detail: night ? "Taxi de ville · nuit, 400 F" : "Taxi de ville · jour, 350 F",
      };
    }
    return {
      price: round50((night ? 1100 : 900) + km * 360),
      km,
      minutes: minutesFor(2.2, 4),
      detail: night ? "Taxi course · nuit" : "Taxi course, hors forfait court",
    };
  }

  return {
    price: round50((night ? 1600 : 1400) + km * 400),
    km,
    minutes: minutesFor(2, 5),
    detail:
      from.far || to.far
        ? "Berline · trajet direct hors centre"
        : night
          ? "Berline · nuit"
          : "Berline · trajet direct",
  };
}

export function closestDriver(vehicle: Vehicle, pickup: Place): Driver {
  const pool = DRIVERS.filter((driver) => driver.vehicle === vehicle);
  return pool.reduce((best, driver) => {
    const bestKm = haversine(placeById(best.home), pickup);
    const nextKm = haversine(placeById(driver.home), pickup);
    if (nextKm < bestKm - 0.01) return driver;
    if (Math.abs(nextKm - bestKm) <= 0.01 && driver.name < best.name) return driver;
    return best;
  });
}

export function mapBounds(focus: Place[]): Bounds {
  const points = [...PLACES.filter((place) => !place.far), ...focus];
  let minLat = Infinity;
  let maxLat = -Infinity;
  let minLng = Infinity;
  let maxLng = -Infinity;
  for (const point of points) {
    minLat = Math.min(minLat, point.lat);
    maxLat = Math.max(maxLat, point.lat);
    minLng = Math.min(minLng, point.lng);
    maxLng = Math.max(maxLng, point.lng);
  }
  const padLat = Math.max(0.0035, (maxLat - minLat) * 0.16);
  const padLng = Math.max(0.0035, (maxLng - minLng) * 0.16);
  return {
    minLat: minLat - padLat,
    maxLat: maxLat + padLat,
    minLng: minLng - padLng,
    maxLng: maxLng + padLng,
  };
}

export function project(point: LatLng, bounds: Bounds): { x: number; y: number } {
  const x = ((point.lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * 100;
  const y = ((bounds.maxLat - point.lat) / (bounds.maxLat - bounds.minLat)) * 100;
  return { x, y };
}

export function fcfa(value: number): string {
  return `${new Intl.NumberFormat("fr-FR").format(value)}\u00a0F`;
}

export function formatKm(km: number): string {
  if (km < 1) {
    const meters = Math.max(40, Math.round((km * 1000) / 10) * 10);
    return `${meters}\u00a0m`;
  }
  return `${km.toFixed(1).replace(".", ",")}\u00a0km`;
}

export function formatKo(kb: number): string {
  const rounded = kb < 10 ? (Math.round(kb * 10) / 10).toFixed(1) : String(Math.round(kb));
  return `${rounded.replace(".", ",")}\u00a0Ko`;
}

export function bertouaNow(date = new Date()): { hour: number; clock: string } {
  const hour = Number(
    new Intl.DateTimeFormat("en-GB", {
      timeZone: "Africa/Douala",
      hour: "numeric",
      hourCycle: "h23",
    }).format(date),
  );
  const clock = new Intl.DateTimeFormat("fr-FR", {
    timeZone: "Africa/Douala",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
  return { hour, clock };
}

export function formatWhen(timestamp: number): string {
  return new Intl.DateTimeFormat("fr-FR", {
    timeZone: "Africa/Douala",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(timestamp));
}

export function initials(name: string): string {
  const parts = name.split(" ").filter(Boolean);
  const first = parts[0]?.[0] ?? "?";
  const second = parts[1]?.[0] ?? "";
  return `${first}${second}`.toUpperCase();
}

export function isNetId(value: unknown): value is NetId {
  return value === "2g" || value === "3g" || value === "4g";
}

export function isPay(value: unknown): value is Pay {
  return value === "cash" || value === "om" || value === "momo";
}
