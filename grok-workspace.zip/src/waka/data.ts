export type Vehicle = "moto" | "taxi" | "berline";
export type Pay = "cash" | "om" | "momo";
export type NetId = "2g" | "3g" | "4g";
export type DetailLevel = "min" | "mid" | "full";

export type Place = {
  id: string;
  name: string;
  zone: string;
  lat: number;
  lng: number;
  hint: string;
  keywords: string;
  far?: boolean;
};

export type Driver = {
  id: string;
  name: string;
  vehicle: Vehicle;
  tone: "warm" | "cool" | "ink";
  colorName: string;
  plate: string;
  rating: string;
  trips: number;
  years: number;
  langs: string;
  home: string;
  phone: string;
};

export const PLACES: Place[] = [
  {
    id: "marche",
    name: "Marché central",
    zone: "Centre-ville",
    lat: 4.5778,
    lng: 13.6846,
    hint: "Le départ le plus demandé",
    keywords: "centre ville marche bertoua",
  },
  {
    id: "hopital",
    name: "Hôpital régional",
    zone: "CENAJES",
    lat: 4.5744,
    lng: 13.6908,
    hint: "Carrefour CENAJES · dès 200 F",
    keywords: "hopital hospital cenajes sante",
  },
  {
    id: "ngaikada",
    name: "Ngaïkada",
    zone: "Centre-ville",
    lat: 4.5756,
    lng: 13.6806,
    hint: "Tout près du marché · 200 F",
    keywords: "ngaikada ngaikada",
  },
  {
    id: "enia",
    name: "Carrefour ENIA",
    zone: "ENIA",
    lat: 4.5802,
    lng: 13.6762,
    hint: "200 à 250 F en moto",
    keywords: "enia carrefour",
  },
  {
    id: "haoussa",
    name: "Quartier Haoussa",
    zone: "Haoussa",
    lat: 4.5832,
    lng: 13.6922,
    hint: "150 à 200 F depuis le centre",
    keywords: "haoussa haussa",
  },
  {
    id: "tindamda",
    name: "Tindamda",
    zone: "Tindamda",
    lat: 4.5852,
    lng: 13.6868,
    hint: "200 F depuis le centre",
    keywords: "tindamba tindamda",
  },
  {
    id: "toungou",
    name: "Toungou",
    zone: "Toungou",
    lat: 4.5872,
    lng: 13.6784,
    hint: "250 à 300 F",
    keywords: "toungou",
  },
  {
    id: "monou1",
    name: "Monou I",
    zone: "Haoussa",
    lat: 4.5864,
    lng: 13.6964,
    hint: "200 F",
    keywords: "monou 1",
  },
  {
    id: "monou2",
    name: "Monou II",
    zone: "Haoussa",
    lat: 4.5892,
    lng: 13.7016,
    hint: "250 à 300 F",
    keywords: "monou 2",
  },
  {
    id: "kano",
    name: "Kano",
    zone: "Kano",
    lat: 4.5702,
    lng: 13.6742,
    hint: "300 F en moto",
    keywords: "kano",
  },
  {
    id: "dubai",
    name: "Kano Traverse · Dubaï",
    zone: "Kano",
    lat: 4.5664,
    lng: 13.6684,
    hint: "IPPOL · 400 F",
    keywords: "dubai dubay ippol traverse",
  },
  {
    id: "touristique",
    name: "Touristique Express",
    zone: "Goliké",
    lat: 4.575,
    lng: 13.6727,
    hint: "Agences · rue Goliké Fabien",
    keywords: "bus gare agence voyage touristique golike",
  },
  {
    id: "mokolo",
    name: "Mokolo Dernier Poteau",
    zone: "Mokolo",
    lat: 4.5632,
    lng: 13.6808,
    hint: "200 à 300 F",
    keywords: "mokolo safari poteau",
  },
  {
    id: "mokolo4",
    name: "Mokolo 4",
    zone: "Mokolo",
    lat: 4.5584,
    lng: 13.6752,
    hint: "300 F",
    keywords: "mokolo 4",
  },
  {
    id: "tigaza",
    name: "Tigaza",
    zone: "Tigaza",
    lat: 4.5668,
    lng: 13.7052,
    hint: "200 F depuis le centre",
    keywords: "tigaza",
  },
  {
    id: "bertoua2",
    name: "Bertoua II",
    zone: "Bertoua II",
    lat: 4.5706,
    lng: 13.6982,
    hint: "Dès 200 F selon le coin",
    keywords: "bertoua 2 deuxieme",
  },
  {
    id: "nyonzengue",
    name: "Nyonzengue",
    zone: "Est",
    lat: 4.5766,
    lng: 13.7044,
    hint: "300 F",
    keywords: "nyonzengue",
  },
  {
    id: "nkolbikon",
    name: "Nkolbikon",
    zone: "Nkolbikon",
    lat: 4.5552,
    lng: 13.6904,
    hint: "Vers le sud de la ville",
    keywords: "nkolbikon npokolota",
  },
  {
    id: "concordia",
    name: "Carrefour Concordia",
    zone: "Nkolbikon",
    lat: 4.5506,
    lng: 13.6786,
    hint: "400 à 500 F",
    keywords: "concordia",
  },
  {
    id: "cub",
    name: "Communauté urbaine",
    zone: "Koumé",
    lat: 4.5844,
    lng: 13.6662,
    hint: "CUB · Martino · 400 à 500 F",
    keywords: "cub koume martino mairie",
  },
  {
    id: "bonis",
    name: "Carrefour Bonis",
    zone: "Bonis",
    lat: 4.593,
    lng: 13.6582,
    hint: "500 F",
    keywords: "bonis source",
  },
  {
    id: "mandjou",
    name: "Mandjou centre",
    zone: "Mandjou",
    lat: 4.568,
    lng: 13.792,
    hint: "Périurbain · dès 500 F en moto",
    keywords: "mandjou",
    far: true,
  },
  {
    id: "aeroport",
    name: "Aéroport BTA",
    zone: "Aéroport",
    lat: 4.5411,
    lng: 13.7261,
    hint: "Voiture 2 000 à 6 000 F",
    keywords: "aeroport airport bta avion fkko",
    far: true,
  },
];

/** Indicative daytime moto fares from the central market, in FCFA. */
export const MOTO_FROM_MARKET: Record<string, number> = {
  hopital: 200,
  ngaikada: 200,
  enia: 250,
  haoussa: 200,
  tindamda: 200,
  toungou: 300,
  monou1: 200,
  monou2: 300,
  kano: 300,
  dubai: 400,
  touristique: 250,
  mokolo: 250,
  mokolo4: 300,
  tigaza: 200,
  bertoua2: 250,
  nyonzengue: 300,
  nkolbikon: 350,
  concordia: 500,
  cub: 450,
  bonis: 500,
  mandjou: 700,
  aeroport: 1500,
};

export const DRIVERS: Driver[] = [
  {
    id: "jp",
    name: "Jean-Pierre Owona",
    vehicle: "moto",
    tone: "warm",
    colorName: "rouge",
    plate: "ES 2144 A",
    rating: "4,8",
    trips: 1260,
    years: 9,
    langs: "français, gbaya",
    home: "marche",
    phone: "6XX XX 21 44",
  },
  {
    id: "sou",
    name: "Souleymane Bello",
    vehicle: "moto",
    tone: "warm",
    colorName: "jaune",
    plate: "ES 0881 B",
    rating: "4,9",
    trips: 2104,
    years: 14,
    langs: "français, fulfuldé",
    home: "haoussa",
    phone: "6XX XX 08 81",
  },
  {
    id: "pat",
    name: "Patrick Mbarga",
    vehicle: "moto",
    tone: "cool",
    colorName: "bleue",
    plate: "ES 3320 C",
    rating: "4,7",
    trips: 980,
    years: 6,
    langs: "français, maka",
    home: "mokolo",
    phone: "6XX XX 33 20",
  },
  {
    id: "cel",
    name: "Célestin Aboui",
    vehicle: "moto",
    tone: "cool",
    colorName: "verte",
    plate: "ES 1502 D",
    rating: "4,6",
    trips: 740,
    years: 4,
    langs: "français, gbaya",
    home: "kano",
    phone: "6XX XX 15 02",
  },
  {
    id: "rog",
    name: "Roger Mekong",
    vehicle: "moto",
    tone: "ink",
    colorName: "noire",
    plate: "ES 2766 E",
    rating: "4,8",
    trips: 1510,
    years: 11,
    langs: "français",
    home: "tigaza",
    phone: "6XX XX 27 66",
  },
  {
    id: "die",
    name: "Dieudonné Nkomo",
    vehicle: "taxi",
    tone: "warm",
    colorName: "jaune",
    plate: "ES 4418 T",
    rating: "4,8",
    trips: 860,
    years: 11,
    langs: "français",
    home: "touristique",
    phone: "6XX XX 44 18",
  },
  {
    id: "mar",
    name: "Martine Essomba",
    vehicle: "taxi",
    tone: "warm",
    colorName: "jaune",
    plate: "ES 2290 T",
    rating: "4,9",
    trips: 640,
    years: 8,
    langs: "français, maka",
    home: "hopital",
    phone: "6XX XX 22 90",
  },
  {
    id: "ib",
    name: "Ibrahim Amadou",
    vehicle: "taxi",
    tone: "ink",
    colorName: "blanche",
    plate: "ES 1176 T",
    rating: "4,7",
    trips: 510,
    years: 5,
    langs: "français, fulfuldé",
    home: "bertoua2",
    phone: "6XX XX 11 76",
  },
  {
    id: "ai",
    name: "Aïcha Nsangou",
    vehicle: "berline",
    tone: "ink",
    colorName: "grise",
    plate: "ES 7004 B",
    rating: "4,9",
    trips: 390,
    years: 7,
    langs: "français",
    home: "cub",
    phone: "6XX XX 70 04",
  },
  {
    id: "bl",
    name: "Blaise Ondoa",
    vehicle: "berline",
    tone: "cool",
    colorName: "noire",
    plate: "ES 6155 B",
    rating: "4,8",
    trips: 280,
    years: 10,
    langs: "français, gbaya",
    home: "enia",
    phone: "6XX XX 61 55",
  },
];

export const VEHICLES: { id: Vehicle; short: string; label: string; hint: string }[] = [
  { id: "moto", short: "Moto", label: "Moto-taxi", hint: "Le quotidien" },
  { id: "taxi", short: "Taxi", label: "Taxi jaune", hint: "Forfait en ville" },
  { id: "berline", short: "Berline", label: "Berline", hint: "Direct, bagages" },
];

export const PAYMENTS: { id: Pay; label: string; hint: string }[] = [
  { id: "cash", label: "Espèces", hint: "Au conducteur" },
  { id: "om", label: "Orange Money", hint: "#150#" },
  { id: "momo", label: "MTN MoMo", hint: "*126#" },
];

export const NETS: Record<
  NetId,
  {
    id: NetId;
    label: string;
    blurb: string;
    requestKb: number;
    pingKb: number;
    pingMs: number;
    matchMs: number;
    detail: DetailLevel;
  }
> = {
  "2g": {
    id: "2g",
    label: "2G",
    blurb: "Texte seul. Ça passe quand la data rame.",
    requestKb: 0.8,
    pingKb: 0.15,
    pingMs: 4500,
    matchMs: 2400,
    detail: "min",
  },
  "3g": {
    id: "3g",
    label: "3G",
    blurb: "Fiche courte, toujours sans photo.",
    requestKb: 1.8,
    pingKb: 0.45,
    pingMs: 2800,
    matchMs: 1100,
    detail: "mid",
  },
  "4g": {
    id: "4g",
    label: "4G",
    blurb: "Fiche complète. Plus vif, plus lourd.",
    requestKb: 8.4,
    pingKb: 1.6,
    pingMs: 1600,
    matchMs: 480,
    detail: "full",
  },
};

export const QUICK_IDS = ["hopital", "kano", "mokolo", "haoussa", "aeroport", "mandjou"] as const;

export const USSD_PLACE_IDS = [
  "marche",
  "hopital",
  "enia",
  "kano",
  "haoussa",
  "mokolo",
  "tigaza",
  "mandjou",
  "aeroport",
] as const;

export const STORAGE_KEY = "waka-bertoua-v1";
