import { useEffect, useRef, useState, type FormEvent } from "react";
import { Bike, Car, CarFront, MapPin, MessageSquare, Phone, Radio, Search, Star, X } from "lucide-react";
import {
  NETS,
  PAYMENTS,
  PLACES,
  QUICK_IDS,
  STORAGE_KEY,
  USSD_PLACE_IDS,
  VEHICLES,
  type DetailLevel,
  type Driver,
  type NetId,
  type Pay,
  type Place,
  type Vehicle,
} from "@/waka/data";
import {
  bertouaNow,
  closestDriver,
  fcfa,
  fold,
  formatKm,
  formatKo,
  formatWhen,
  haversine,
  initials,
  isNetId,
  isNight,
  isPay,
  mapBounds,
  payLabel,
  placeById,
  project,
  quote,
  round1,
  vehicleMeta,
  type LatLng,
  type Quote,
  type SavedTrip,
} from "@/waka/logic";

type RidePhase = "idle" | "match" | "arrive" | "ride" | "done";
type Sheet = "plan" | "pick" | "history";
type PickTarget = "pickup" | "dropoff";

type ActiveTrip = {
  id: string;
  pickup: Place;
  dropoff: Place;
  vehicle: Vehicle;
  price: number;
  km: number;
  minutes: number;
  detail: string;
  driver: Driver;
  pay: Pay;
  spent: number;
};

type UssdStep = "home" | "vehicle" | "from" | "to" | "confirm" | "receipts";

type Prefs = { net: NetId; pay: Pay; trips: SavedTrip[] };

function loadPrefs(): Prefs {
  const fallback: Prefs = { net: "2g", pay: "cash", trips: [] };
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as Partial<Prefs>;
    return {
      net: isNetId(parsed.net) ? parsed.net : "2g",
      pay: isPay(parsed.pay) ? parsed.pay : "cash",
      trips: Array.isArray(parsed.trips) ? parsed.trips.slice(0, 30) : [],
    };
  } catch {
    return fallback;
  }
}

function VehicleIcon({ id, className }: { id: Vehicle; className?: string }) {
  const cls = className ?? "size-4";
  if (id === "moto") return <Bike className={cls} aria-hidden="true" />;
  if (id === "taxi") return <Car className={cls} aria-hidden="true" />;
  return <CarFront className={cls} aria-hidden="true" />;
}

function toneClass(tone: Driver["tone"]): string {
  if (tone === "warm") return "bg-laterite text-paper";
  if (tone === "cool") return "bg-forest text-paper";
  return "bg-ink text-paper";
}

export function WakaApp() {
  const boot = useRef(loadPrefs());
  const now = useRef(bertouaNow());
  const [net, setNet] = useState<NetId>(boot.current.net);
  const [pay, setPay] = useState<Pay>(boot.current.pay);
  const [trips, setTrips] = useState<SavedTrip[]>(boot.current.trips);
  const [kb, setKb] = useState(1.2);
  const [hour] = useState(now.current.hour);
  const [clock] = useState(now.current.clock);

  const [ride, setRide] = useState<RidePhase>("idle");
  const [sheet, setSheet] = useState<Sheet>("plan");
  const [pickFor, setPickFor] = useState<PickTarget>("dropoff");
  const [query, setQuery] = useState("");
  const [pickupId, setPickupId] = useState("marche");
  const [dropoffId, setDropoffId] = useState<string | null>(null);
  const [vehicle, setVehicle] = useState<Vehicle>("moto");
  const [active, setActive] = useState<ActiveTrip | null>(null);
  const [marker, setMarker] = useState<LatLng | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [ussdOpen, setUssdOpen] = useState(false);

  const savedId = useRef<string | null>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ net, pay, trips }));
  }, [net, pay, trips]);

  const pickup = placeById(pickupId);
  const dropoff = dropoffId ? placeById(dropoffId) : null;
  const selectedQuote: Quote | null = dropoff ? quote(pickup, dropoff, vehicle, hour) : null;
  const night = isNight(hour);

  const spend = (amount: number) => {
    setKb((value) => round1(value + amount));
    setActive((current) =>
      current ? { ...current, spent: round1(current.spent + amount) } : current,
    );
  };

  const requestRide = (next?: {
    vehicle?: Vehicle;
    pickup?: Place;
    dropoff?: Place;
    pay?: Pay;
  }) => {
    const chosenVehicle = next?.vehicle ?? vehicle;
    const from = next?.pickup ?? pickup;
    const to = next?.dropoff ?? dropoff;
    const chosenPay = next?.pay ?? pay;
    if (!to) return;
    const priced = quote(from, to, chosenVehicle, hour);
    if (priced.blocked) {
      setNote(priced.blocked);
      return;
    }
    const driver = closestDriver(chosenVehicle, from);
    const spent = NETS[net].requestKb;
    setVehicle(chosenVehicle);
    setPickupId(from.id);
    setDropoffId(to.id);
    setPay(chosenPay);
    setNote(null);
    setSheet("plan");
    setUssdOpen(false);
    setMarker(placeById(driver.home));
    setKb((value) => round1(value + spent));
    setActive({
      id: `${Date.now()}`,
      pickup: from,
      dropoff: to,
      vehicle: chosenVehicle,
      price: priced.price,
      km: priced.km,
      minutes: priced.minutes,
      detail: priced.detail,
      driver,
      pay: chosenPay,
      spent,
    });
    setRide("match");
  };

  const cancelRide = () => {
    setRide("idle");
    setActive(null);
    setMarker(null);
    setNote(null);
  };

  const newCourse = () => {
    setRide("idle");
    setActive(null);
    setMarker(null);
    setDropoffId(null);
    setNote(null);
    setSheet("plan");
  };

  useEffect(() => {
    if (ride !== "match" || !active) return;
    const timer = window.setTimeout(() => setRide("arrive"), NETS[net].matchMs);
    return () => window.clearTimeout(timer);
  }, [ride, net, active?.id]);

  useEffect(() => {
    if ((ride !== "arrive" && ride !== "ride") || !active) return;
    const from = ride === "arrive" ? placeById(active.driver.home) : active.pickup;
    const to = ride === "arrive" ? active.pickup : active.dropoff;
    const distance = haversine(from, to);
    const ms = Math.min(9000, Math.max(1800, distance * 2600));
    let stopped = false;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const finish = () => {
      if (stopped) return;
      stopped = true;
      setMarker(to);
      setRide(ride === "arrive" ? "ride" : "done");
    };

    if (reduced) {
      const timer = window.setTimeout(finish, 500);
      return () => {
        stopped = true;
        window.clearTimeout(timer);
      };
    }

    const started = performance.now();
    let frame = 0;
    const tick = (nowMs: number) => {
      if (stopped) return;
      const t = Math.min(1, (nowMs - started) / ms);
      const eased = 1 - (1 - t) ** 2;
      setMarker({
        lat: from.lat + (to.lat - from.lat) * eased,
        lng: from.lng + (to.lng - from.lng) * eased,
      });
      if (t < 1) frame = requestAnimationFrame(tick);
      else finish();
    };
    frame = requestAnimationFrame(tick);
    return () => {
      stopped = true;
      cancelAnimationFrame(frame);
    };
  }, [ride, active?.id]);

  useEffect(() => {
    if (ride !== "arrive" && ride !== "ride") return;
    const amount = NETS[net].pingKb;
    const timer = window.setInterval(() => {
      setKb((value) => round1(value + amount));
      setActive((current) =>
        current ? { ...current, spent: round1(current.spent + amount) } : current,
      );
    }, NETS[net].pingMs);
    return () => window.clearInterval(timer);
  }, [ride, net]);

  useEffect(() => {
    if (ride !== "done" || !active) return;
    if (savedId.current === active.id) return;
    savedId.current = active.id;
    const spent = round1(active.spent + 0.2);
    const trip: SavedTrip = {
      id: active.id,
      at: Date.now(),
      from: active.pickup.name,
      to: active.dropoff.name,
      vehicle: active.vehicle,
      price: active.price,
      pay: active.pay,
      km: active.km,
      driver: active.driver.name,
      spent,
    };
    setTrips((current) => [trip, ...current.filter((item) => item.id !== trip.id)].slice(0, 30));
    setKb((value) => round1(value + 0.2));
    setActive((current) => (current ? { ...current, spent } : current));
  }, [ride, active?.id]);

  const focus: Place[] = [pickup];
  if (dropoff) focus.push(dropoff);
  if (marker) {
    focus.push({
      id: "live",
      name: "live",
      zone: "",
      lat: marker.lat,
      lng: marker.lng,
      hint: "",
      keywords: "",
      far: true,
    });
  }
  const bounds = mapBounds(focus);

  const liveTarget = active ? (ride === "ride" || ride === "done" ? active.dropoff : active.pickup) : null;
  const remaining =
    marker && liveTarget && (ride === "arrive" || ride === "ride")
      ? haversine(marker, liveTarget)
      : null;

  const openPick = (target: PickTarget) => {
    if (ride === "match" || ride === "arrive" || ride === "ride") return;
    setPickFor(target);
    setQuery("");
    setNote(null);
    setSheet("pick");
  };

  const choosePlace = (id: string) => {
    if (pickFor === "pickup") {
      setPickupId(id);
      if (id === dropoffId) setDropoffId(null);
    } else if (id === pickupId) {
      setNote("Choisissez un autre point que le départ.");
      return;
    } else {
      setDropoffId(id);
    }
    setNote(null);
    setQuery("");
    setSheet("plan");
  };

  const status =
    ride === "match"
      ? "Recherche d’un conducteur"
      : ride === "arrive"
        ? `${active?.driver.name ?? "Le conducteur"} approche`
        : ride === "ride"
          ? "Course en cours"
          : ride === "done"
            ? "Course terminée"
            : "Prêt à réserver";

  return (
    <div className="flex min-h-dvh flex-col bg-sand text-ink lg:h-dvh lg:overflow-hidden">
      <div className="h-1 shrink-0 bg-forest" />
      <header className="z-20 flex shrink-0 items-center justify-between gap-3 bg-sand px-4 py-3">
        <div className="min-w-0">
          <div className="flex items-baseline gap-2">
            <p className="font-display text-2xl leading-none font-semibold text-forest">Waka</p>
            <p className="truncate text-xs font-semibold tracking-widest text-muted uppercase">Bertoua</p>
          </div>
          <p className="mt-1 text-xs text-muted">
            {clock} · {night ? "nuit" : "jour"} · {formatKo(kb)}
          </p>
        </div>
        <div className="flex flex-col items-end gap-1">
          <div role="radiogroup" aria-label="Réseau" className="flex rounded-full border border-line bg-paper p-1">
            {(Object.keys(NETS) as NetId[]).map((id) => {
              const on = net === id;
              return (
                <button
                  key={id}
                  type="button"
                  role="radio"
                  aria-checked={on}
                  onClick={() => setNet(id)}
                  className={`press h-8 min-w-10 rounded-full px-2.5 text-xs font-semibold ${
                    on ? "bg-forest text-paper" : "text-muted"
                  }`}
                >
                  {NETS[id].label}
                </button>
              );
            })}
          </div>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => setUssdOpen(true)}
              className="inline-flex h-6 items-center gap-1 text-xs font-semibold text-forest"
            >
              <Radio className="size-3.5" aria-hidden="true" />
              *214#
            </button>
            <button
              type="button"
              onClick={() => setSheet("history")}
              className="h-6 text-xs font-semibold text-muted"
            >
              Reçus
            </button>
          </div>
        </div>
      </header>

      <div className="flex flex-1 flex-col lg:min-h-0 lg:grid lg:grid-cols-3">
        <div className="relative h-72 overflow-hidden lg:col-span-2 lg:h-auto lg:min-h-0">
          <CityMap
            bounds={bounds}
            pickupId={active?.pickup.id ?? pickupId}
            dropoffId={active?.dropoff.id ?? dropoffId}
            marker={marker}
            driver={active?.driver ?? null}
            onPick={(id) => {
              if (ride === "match" || ride === "arrive" || ride === "ride") return;
              if (id === pickupId) return;
              setDropoffId(id);
              setSheet("plan");
              setNote(null);
            }}
          />
        </div>

        <section className="relative z-10 -mt-5 flex-1 rounded-t-3xl border border-line bg-sand px-4 pt-5 pb-8 lg:col-span-1 lg:mt-0 lg:overflow-y-auto lg:rounded-none lg:border-y-0 lg:border-r-0 lg:border-l lg:pb-6">
          <p className="sr-only" aria-live="polite">
            {status}
          </p>
          {sheet === "history" ? (
            <HistoryPanel
              trips={trips}
              onBack={() => setSheet("plan")}
              live={ride === "match" || ride === "arrive" || ride === "ride"}
            />
          ) : sheet === "pick" && ride !== "match" && ride !== "arrive" && ride !== "ride" ? (
            <PickPanel
              target={pickFor}
              query={query}
              onQuery={setQuery}
              onBack={() => setSheet("plan")}
              onChoose={choosePlace}
            />
          ) : ride === "match" && active ? (
            <MatchPanel net={net} active={active} onCancel={cancelRide} />
          ) : (ride === "arrive" || ride === "ride") && active ? (
            <LivePanel
              ride={ride}
              active={active}
              net={net}
              remaining={remaining}
              note={note}
              onCancel={cancelRide}
              onCall={() =>
                setNote(
                  `Appel vers ${active.driver.phone}. En 2G la voix passe encore si la data coupe. Signalisation 0,2 Ko.`,
                )
              }
              onSms={() => {
                spend(0.2);
                setNote("SMS parti vers le conducteur. 0,2 Ko.");
              }}
            />
          ) : ride === "done" && active ? (
            <DonePanel active={active} onNew={newCourse} onHistory={() => setSheet("history")} />
          ) : (
            <PlanPanel
              net={net}
              hour={hour}
              night={night}
              pickup={pickup}
              dropoff={dropoff}
              vehicle={vehicle}
              pay={pay}
              quote={selectedQuote}
              note={note}
              onPick={openPick}
              onQuick={(id) => {
                if (id === pickupId) {
                  setNote("Ce point est déjà le départ.");
                  return;
                }
                setDropoffId(id);
                setNote(null);
              }}
              onVehicle={setVehicle}
              onPay={setPay}
              onRequest={() => requestRide()}
            />
          )}
        </section>
      </div>

      {ussdOpen ? (
        <Ussd
          net={net}
          hour={hour}
          trips={trips}
          onClose={() => setUssdOpen(false)}
          onNet={setNet}
          onBook={(from, to, chosen) => requestRide({ pickup: from, dropoff: to, vehicle: chosen })}
        />
      ) : null}
    </div>
  );
}

function CityMap({
  bounds,
  pickupId,
  dropoffId,
  marker,
  driver,
  onPick,
}: {
  bounds: ReturnType<typeof mapBounds>;
  pickupId: string;
  dropoffId: string | null;
  marker: LatLng | null;
  driver: Driver | null;
  onPick: (id: string) => void;
}) {
  const visible = PLACES.filter((place) => {
    if (!place.far) return true;
    return place.id === pickupId || place.id === dropoffId;
  });
  const driverPoint = marker ? project(marker, bounds) : null;

  return (
    <div className="map-field relative h-full min-h-72 w-full">
      {visible.map((place) => {
        const point = project(place, bounds);
        const role = place.id === pickupId ? "départ" : place.id === dropoffId ? "arrivée" : "quartier";
        const selected = place.id === pickupId || place.id === dropoffId;
        return (
          <button
            key={place.id}
            type="button"
            aria-label={`${place.name}, ${role}`}
            onClick={() => onPick(place.id)}
            className="absolute z-10 flex size-11 -translate-x-1/2 -translate-y-1/2 items-center justify-center"
            style={{ left: `${point.x}%`, top: `${point.y}%` }}
          >
            <span className="flex flex-col items-center">
              {selected ? (
                <span className="mb-1 rounded-full border border-line bg-paper px-2 py-0.5 text-xs font-medium whitespace-nowrap text-ink">
                  {place.name}
                </span>
              ) : null}
              <span
                className={`block rounded-full border-2 border-paper ${
                  place.id === dropoffId
                    ? "size-5 bg-laterite"
                    : place.id === pickupId
                      ? "size-5 bg-forest"
                      : "size-3.5 bg-forest-deep"
                }`}
              />
            </span>
          </button>
        );
      })}

      {driverPoint && driver ? (
        <div
          className="absolute z-20 -translate-x-1/2 -translate-y-1/2"
          style={{ left: `${driverPoint.x}%`, top: `${driverPoint.y}%` }}
        >
          <span className="relative flex size-11 items-center justify-center">
            <span className="pulse-ring absolute inset-0 rounded-full bg-forest" />
            <span
              className={`relative flex size-11 items-center justify-center rounded-full border-2 border-paper ${toneClass(driver.tone)}`}
            >
              <VehicleIcon id={driver.vehicle} className="size-5" />
            </span>
          </span>
        </div>
      ) : null}

      <div className="pointer-events-none absolute inset-x-0 bottom-6 flex items-end justify-between px-4 lg:bottom-4">
        <p className="rounded-full bg-paper/90 px-3 py-1 text-xs font-medium text-forest-deep">
          Carte locale · sans tuiles
        </p>
        <p className="hidden rounded-full bg-paper/90 px-3 py-1 text-xs text-muted sm:block">
          Vert départ · ocre arrivée
        </p>
      </div>
    </div>
  );
}

function PlanPanel({
  net,
  hour,
  night,
  pickup,
  dropoff,
  vehicle,
  pay,
  quote: priced,
  note,
  onPick,
  onQuick,
  onVehicle,
  onPay,
  onRequest,
}: {
  net: NetId;
  hour: number;
  night: boolean;
  pickup: Place;
  dropoff: Place | null;
  vehicle: Vehicle;
  pay: Pay;
  quote: Quote | null;
  note: string | null;
  onPick: (target: PickTarget) => void;
  onQuick: (id: string) => void;
  onVehicle: (id: Vehicle) => void;
  onPay: (id: Pay) => void;
  onRequest: () => void;
}) {
  const spec = NETS[net];
  const blocked = priced?.blocked;
  const label = !dropoff
    ? "Choisir une arrivée"
    : blocked
      ? "Moto indisponible"
      : `Demander · ${fcfa(priced?.price ?? 0)}`;

  return (
    <div>
      <h1 className="font-display text-3xl leading-tight font-semibold text-ink">Où va-t-on ?</h1>
      <p className="mt-1 text-sm text-muted">
        {spec.blurb} Demande {formatKo(spec.requestKb)}. Les quartiers sont déjà dans le téléphone.
      </p>

      <div className="mt-4 grid gap-2">
        <PlaceField label="Départ" value={pickup.name} mark="bg-forest" onClick={() => onPick("pickup")} />
        <PlaceField
          label="Arrivée"
          value={dropoff?.name ?? "Choisir un quartier"}
          mark={dropoff ? "bg-laterite" : "bg-line"}
          muted={!dropoff}
          onClick={() => onPick("dropoff")}
        />
      </div>

      <div className="scroll-x mt-3 flex gap-2 pb-1">
        {QUICK_IDS.map((id) => {
          const place = placeById(id);
          const on = dropoff?.id === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onQuick(id)}
              className={`press h-10 shrink-0 rounded-full border px-3 text-sm font-medium ${
                on ? "border-forest bg-foam text-forest-deep" : "border-line bg-paper text-ink"
              }`}
            >
              {place.name.replace(" Dernier Poteau", "").replace("Carrefour ", "")}
            </button>
          );
        })}
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2" role="radiogroup" aria-label="Véhicule">
        {VEHICLES.map((item) => {
          const on = vehicle === item.id;
          const sample = dropoff ? quote(pickup, dropoff, item.id, hour) : null;
          return (
            <button
              key={item.id}
              type="button"
              role="radio"
              aria-checked={on}
              onClick={() => onVehicle(item.id)}
              className={`press flex min-h-24 flex-col items-start justify-between rounded-2xl border px-3 py-3 text-left ${
                on ? "border-forest bg-foam" : "border-line bg-paper"
              }`}
            >
              <VehicleIcon id={item.id} className={on ? "size-4 text-forest" : "size-4 text-muted"} />
              <span>
                <span className="block text-sm font-semibold">{item.short}</span>
                <span className="block text-xs text-muted">
                  {sample?.blocked ? "Fermée" : sample ? fcfa(sample.price) : item.hint}
                </span>
              </span>
            </button>
          );
        })}
      </div>

      {priced && !priced.blocked ? (
        <p className="mt-3 text-sm text-muted">
          {priced.detail} · {formatKm(priced.km)} · environ {priced.minutes} min sur la route
          {night ? " · tarif de nuit" : ""}
        </p>
      ) : null}

      <div className="mt-4 flex flex-wrap gap-2" role="radiogroup" aria-label="Paiement">
        {PAYMENTS.map((item) => {
          const on = pay === item.id;
          return (
            <button
              key={item.id}
              type="button"
              role="radio"
              aria-checked={on}
              onClick={() => onPay(item.id)}
              className={`press min-h-10 rounded-full border px-3 py-2 text-sm font-medium ${
                on ? "border-forest bg-forest text-paper" : "border-line bg-paper text-ink"
              }`}
            >
              {item.label}
              <span className={on ? "text-paper/80" : "text-muted"}> · {item.hint}</span>
            </button>
          );
        })}
      </div>

      <button
        type="button"
        disabled={!dropoff || Boolean(blocked)}
        onClick={onRequest}
        className="press mt-4 flex h-14 w-full items-center justify-center rounded-2xl bg-forest text-base font-semibold text-paper disabled:opacity-40"
      >
        {label}
      </button>

      {note ? <p className="mt-3 rounded-2xl bg-clay px-3 py-2 text-sm text-ink">{note}</p> : null}
      {blocked ? <p className="mt-3 rounded-2xl bg-clay px-3 py-2 text-sm text-ink">{blocked}</p> : null}

      <aside className="mt-5 rounded-2xl bg-paper px-4 py-4">
        <p className="text-sm font-semibold text-ink">Face à Yango, à Bertoua</p>
        <p className="mt-1 text-sm text-muted">
          Yango est taillé pour une grande ville et une carte lourde. Ici, la plupart des trajets se font en
          moto, souvent en espèces, parfois avec une seule barre. Waka fixe le prix avant de partir, garde
          Kano, Mokolo, l’hôpital et Mandjou dans le téléphone, et bascule sur le *214# si l’écran ne charge
          plus.
        </p>
      </aside>
      <p className="mt-3 text-xs text-muted">
        Tarifs indicatifs de journée, arrondis à 50 F. Le taxi court suit le repère local : 350 F le jour, 400
        F la nuit. Démo : aucun paiement réel.
      </p>
      {hour >= 0 && hour < 6 ? (
        <p className="mt-2 text-xs text-muted">Entre minuit et 6 h, Waka ne propose que le taxi ou la berline.</p>
      ) : null}
    </div>
  );
}

function PlaceField({
  label,
  value,
  mark,
  muted,
  onClick,
}: {
  label: string;
  value: string;
  mark: string;
  muted?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="press flex h-14 w-full items-center gap-3 rounded-2xl border border-line bg-paper px-3 text-left"
    >
      <span className={`size-2.5 shrink-0 rounded-full ${mark}`} />
      <span className="min-w-0">
        <span className="block text-xs text-muted">{label}</span>
        <span className={`block truncate font-medium ${muted ? "text-muted" : "text-ink"}`}>{value}</span>
      </span>
    </button>
  );
}

function PickPanel({
  target,
  query,
  onQuery,
  onBack,
  onChoose,
}: {
  target: PickTarget;
  query: string;
  onQuery: (value: string) => void;
  onBack: () => void;
  onChoose: (id: string) => void;
}) {
  const filtered = PLACES.filter((place) => {
    if (!query.trim()) return true;
    return fold(`${place.name} ${place.zone} ${place.hint} ${place.keywords}`).includes(fold(query.trim()));
  });
  const groups: { zone: string; places: Place[] }[] = [];
  for (const place of filtered) {
    const group = groups.find((item) => item.zone === place.zone);
    if (group) group.places.push(place);
    else groups.push({ zone: place.zone, places: [place] });
  }

  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <h2 className="font-display text-2xl font-semibold">
          {target === "pickup" ? "Point de départ" : "Arrivée"}
        </h2>
        <button type="button" onClick={onBack} className="text-sm font-semibold text-forest">
          Fermer
        </button>
      </div>
      <label className="mt-3 flex h-12 items-center gap-2 rounded-2xl border border-line bg-paper px-3">
        <Search className="size-4 text-muted" aria-hidden="true" />
        <input
          value={query}
          onChange={(event) => onQuery(event.target.value)}
          placeholder="Kano, hôpital, Mandjou…"
          className="h-full w-full bg-transparent text-base text-ink outline-none placeholder:text-muted"
        />
      </label>
      <p className="mt-2 text-xs text-muted">Recherche locale. 0 Ko.</p>
      <div className="mt-2">
        {groups.length === 0 ? (
          <p className="py-6 text-sm text-muted">Aucun quartier pour « {query} ».</p>
        ) : (
          groups.map((group) => (
            <div key={group.zone} className="mt-3">
              <p className="text-xs font-semibold tracking-widest text-muted uppercase">{group.zone}</p>
              {group.places.map((place) => (
                <button
                  key={place.id}
                  type="button"
                  onClick={() => onChoose(place.id)}
                  className="flex min-h-14 w-full items-center gap-3 border-b border-line py-2 text-left"
                >
                  <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-foam text-forest">
                    <MapPin className="size-4" aria-hidden="true" />
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate font-medium">{place.name}</span>
                    <span className="block truncate text-sm text-muted">{place.hint}</span>
                  </span>
                </button>
              ))}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function MatchPanel({ net, active, onCancel }: { net: NetId; active: ActiveTrip; onCancel: () => void }) {
  const spec = NETS[net];
  return (
    <div>
      <p className="text-sm font-semibold text-forest">Recherche</p>
      <h2 className="mt-1 font-display text-3xl leading-tight font-semibold">
        Un {vehicleMeta(active.vehicle).short.toLowerCase()} en {spec.label}
      </h2>
      <p className="mt-2 text-sm text-muted">
        {active.pickup.name} vers {active.dropoff.name}. {spec.blurb} Cette demande : {formatKo(active.spent)}.
      </p>
      <div className="mt-5 h-1.5 overflow-hidden rounded-full bg-line">
        <div className="bar-slide h-full w-1/3 rounded-full bg-forest" />
      </div>
      <button
        type="button"
        onClick={onCancel}
        className="press mt-6 flex h-12 w-full items-center justify-center rounded-2xl border border-line bg-paper font-semibold"
      >
        Annuler
      </button>
    </div>
  );
}

function LivePanel({
  ride,
  active,
  net,
  remaining,
  note,
  onCancel,
  onCall,
  onSms,
}: {
  ride: "arrive" | "ride";
  active: ActiveTrip;
  net: NetId;
  remaining: number | null;
  note: string | null;
  onCancel: () => void;
  onCall: () => void;
  onSms: () => void;
}) {
  const detail = NETS[net].detail;
  const progress =
    ride === "ride" ? Math.max(8, Math.min(100, Math.round((1 - (remaining ?? 0) / Math.max(active.km, 0.05)) * 100))) : 0;

  return (
    <div>
      <p className="text-sm font-semibold text-forest">{ride === "arrive" ? "En approche" : "En course"}</p>
      <h2 className="mt-1 font-display text-3xl leading-tight font-semibold">
        {ride === "arrive" ? active.driver.name.split(" ")[0] : active.dropoff.name}
      </h2>
      <p className="mt-1 text-sm text-muted">
        {ride === "arrive"
          ? remaining !== null && remaining < 0.12
            ? "Déjà au point de départ · suivi accéléré"
            : `${remaining !== null ? formatKm(remaining) : "—"} du départ · suivi accéléré`
          : `${remaining !== null ? formatKm(remaining) : "—"} restants · prix fixé`}
      </p>

      <DriverCard driver={active.driver} vehicle={active.vehicle} detail={detail} />

      {ride === "ride" ? (
        <div className="mt-4 h-2 overflow-hidden rounded-full bg-line">
          <div className="h-full rounded-full bg-forest" style={{ width: `${progress}%` }} />
        </div>
      ) : null}

      <p className="mt-4 font-display text-3xl font-semibold text-forest-deep">{fcfa(active.price)}</p>
      <p className="text-sm text-muted">
        {payLabel(active.pay)} · {formatKm(active.km)} · {active.detail}
      </p>
      <p className="mt-1 text-xs text-muted">
        Données de la course {formatKo(active.spent)} · réseau {NETS[net].label}
      </p>

      <div className="mt-4 grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={onCall}
          className="press flex h-12 items-center justify-center gap-2 rounded-2xl border border-line bg-paper text-sm font-semibold"
        >
          <Phone className="size-4" aria-hidden="true" />
          Appeler
        </button>
        <button
          type="button"
          onClick={onSms}
          className="press flex h-12 items-center justify-center gap-2 rounded-2xl border border-line bg-paper text-sm font-semibold"
        >
          <MessageSquare className="size-4" aria-hidden="true" />
          SMS
        </button>
      </div>
      {note ? <p className="mt-3 rounded-2xl bg-foam px-3 py-2 text-sm text-forest-deep">{note}</p> : null}
      {ride === "arrive" ? (
        <button
          type="button"
          onClick={onCancel}
          className="press mt-3 flex h-12 w-full items-center justify-center rounded-2xl text-sm font-semibold text-muted"
        >
          Annuler la course
        </button>
      ) : (
        <p className="mt-3 text-xs text-muted">Durée estimée sur la route : {active.minutes} min. L’aperçu est accéléré.</p>
      )}
    </div>
  );
}

function DriverCard({
  driver,
  vehicle,
  detail,
}: {
  driver: Driver;
  vehicle: Vehicle;
  detail: DetailLevel;
}) {
  return (
    <article className="mt-4 flex gap-3 rounded-2xl border border-line bg-paper p-3">
      <span
        className={`flex size-14 shrink-0 items-center justify-center rounded-full font-display text-xl ${toneClass(driver.tone)}`}
      >
        {initials(driver.name)}
      </span>
      <div className="min-w-0">
        <p className="truncate font-semibold">{driver.name}</p>
        <p className="text-sm text-muted">
          {vehicleMeta(vehicle).label} {driver.colorName}
        </p>
        <p className="mt-1 inline-flex rounded-md border border-ink px-2 py-0.5 text-xs font-semibold tracking-widest">
          {driver.plate}
        </p>
        <p className="mt-1 flex items-center gap-1 text-sm">
          <Star className="size-3.5 fill-laterite text-laterite" aria-hidden="true" />
          {driver.rating}
          {detail !== "min" ? <span className="text-muted">· {driver.trips} courses</span> : null}
        </p>
        {detail === "full" ? (
          <p className="text-sm text-muted">
            {driver.years} ans · {driver.langs}
          </p>
        ) : null}
      </div>
    </article>
  );
}

function DonePanel({
  active,
  onNew,
  onHistory,
}: {
  active: ActiveTrip;
  onNew: () => void;
  onHistory: () => void;
}) {
  return (
    <div>
      <p className="text-sm font-semibold text-forest">Course terminée</p>
      <h2 className="mt-1 font-display text-4xl font-semibold text-forest-deep">{fcfa(active.price)}</h2>
      <article className="mt-4 rounded-2xl border border-dashed border-line bg-paper p-4">
        <p className="text-xs font-semibold tracking-widest text-muted uppercase">Reçu Waka</p>
        <p className="mt-2 font-medium">
          {active.pickup.name} → {active.dropoff.name}
        </p>
        <p className="mt-1 text-sm text-muted">
          {vehicleMeta(active.vehicle).label} · {active.driver.name}
        </p>
        <p className="text-sm text-muted">
          {formatKm(active.km)} · {payLabel(active.pay)} · {active.driver.plate}
        </p>
        <p className="mt-3 text-sm text-muted">
          SMS de reçu envoyé · données de la course {formatKo(active.spent)}.
        </p>
      </article>
      <button
        type="button"
        onClick={onNew}
        className="press mt-4 flex h-14 w-full items-center justify-center rounded-2xl bg-forest text-base font-semibold text-paper"
      >
        Nouvelle course
      </button>
      <button type="button" onClick={onHistory} className="mt-2 h-11 w-full text-sm font-semibold text-forest">
        Voir les reçus
      </button>
      <p className="mt-2 text-xs text-muted">Démo. Aucun Mobile Money n’a été débité.</p>
    </div>
  );
}

function HistoryPanel({ trips, onBack, live }: { trips: SavedTrip[]; onBack: () => void; live: boolean }) {
  return (
    <div>
      <div className="flex items-center justify-between">
        <h2 className="font-display text-2xl font-semibold">Reçus</h2>
        <button type="button" onClick={onBack} className="text-sm font-semibold text-forest">
          {live ? "Course en cours" : "Retour"}
        </button>
      </div>
      {trips.length === 0 ? (
        <p className="mt-4 text-sm text-muted">
          Aucune course pour l’instant. Du marché à Kano, la moto tourne souvent autour de 300 F.
        </p>
      ) : (
        <ul className="mt-3">
          {trips.map((trip) => (
            <li key={trip.id} className="border-b border-line py-3">
              <div className="flex items-baseline justify-between gap-3">
                <p className="min-w-0 truncate font-medium">
                  {trip.from} → {trip.to}
                </p>
                <p className="shrink-0 font-semibold text-forest-deep">{fcfa(trip.price)}</p>
              </div>
              <p className="text-sm text-muted">
                {vehicleMeta(trip.vehicle).short} · {trip.driver} · {payLabel(trip.pay)}
              </p>
              <p className="text-xs text-muted">
                {formatWhen(trip.at)} · {formatKm(trip.km)} · {formatKo(trip.spent)}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function Ussd({
  net,
  hour,
  trips,
  onClose,
  onNet,
  onBook,
}: {
  net: NetId;
  hour: number;
  trips: SavedTrip[];
  onClose: () => void;
  onNet: (id: NetId) => void;
  onBook: (from: Place, to: Place, vehicle: Vehicle) => void;
}) {
  const [step, setStep] = useState<UssdStep>("home");
  const [digit, setDigit] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [vehicle, setVehicle] = useState<Vehicle>("moto");
  const [fromId, setFromId] = useState<string | null>(null);
  const [toId, setToId] = useState<string | null>(null);

  const places = USSD_PLACE_IDS.map((id) => placeById(id));

  const handle = (raw: string) => {
    const choice = raw.trim();
    setError(null);
    if (choice === "0" && step !== "home") {
      const back: Record<UssdStep, UssdStep> = {
        home: "home",
        vehicle: "home",
        from: "vehicle",
        to: "from",
        confirm: "to",
        receipts: "home",
      };
      setStep(back[step]);
      return;
    }
    if (step === "home") {
      if (choice === "1") setStep("vehicle");
      else if (choice === "2") setStep("receipts");
      else if (choice === "3") {
        const order: NetId[] = ["2g", "3g", "4g"];
        const next = order[(order.indexOf(net) + 1) % order.length] ?? "2g";
        onNet(next);
        setError(`Réseau passé en ${NETS[next].label}.`);
      } else setError("Choix invalide.");
      return;
    }
    if (step === "vehicle") {
      const map: Record<string, Vehicle> = { "1": "moto", "2": "taxi", "3": "berline" };
      const chosen = map[choice];
      if (!chosen) {
        setError("Choix invalide.");
        return;
      }
      setVehicle(chosen);
      setStep("from");
      return;
    }
    if (step === "from" || step === "to") {
      const index = Number(choice) - 1;
      const place = places[index];
      if (!place) {
        setError("Numéro inconnu.");
        return;
      }
      if (step === "from") {
        setFromId(place.id);
        setStep("to");
      } else {
        if (place.id === fromId) {
          setError("Même point. Choisissez une autre arrivée.");
          return;
        }
        setToId(place.id);
        setStep("confirm");
      }
      return;
    }
    if (step === "confirm") {
      if (choice !== "1") {
        if (choice === "2") setStep("home");
        else setError("1 pour confirmer, 2 pour annuler.");
        return;
      }
      if (!fromId || !toId) return;
      const from = placeById(fromId);
      const to = placeById(toId);
      const priced = quote(from, to, vehicle, hour);
      if (priced.blocked) {
        setError(priced.blocked);
        return;
      }
      onBook(from, to, vehicle);
    }
  };

  const onSubmit = (event: FormEvent) => {
    event.preventDefault();
    handle(digit);
    setDigit("");
  };

  const lines = ussdLines(step, places, vehicle, fromId, toId, hour, trips, net);

  return (
    <div className="fixed inset-0 z-30 flex items-end justify-center bg-ink/50 p-3 sm:items-center">
      <div className="flex max-h-[90dvh] w-full max-w-sm flex-col overflow-hidden rounded-3xl border border-forest bg-forest-deep text-paper">
        <div className="flex items-center justify-between px-4 pt-4">
          <div>
            <p className="font-display text-xl font-semibold">Waka · *214#</p>
            <p className="text-xs text-paper/70">Canal USSD · {NETS[net].label} · session légère</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer le canal USSD"
            className="flex size-11 items-center justify-center rounded-full"
          >
            <X className="size-5" />
          </button>
        </div>
        <div className="mt-3 flex-1 overflow-y-auto px-4 pb-3 text-sm leading-relaxed">
          {lines.map((line) => (
            <p key={line}>{line}</p>
          ))}
          {error ? <p className="mt-3 text-clay">{error}</p> : null}
          <p className="mt-4 text-xs text-paper/70">
            *214# ne remplace pas le *126# MoMo ni le #150# Orange. 0 revient en arrière.
          </p>
        </div>
        <form onSubmit={onSubmit} className="flex gap-2 border-t border-paper/20 p-3">
          <input
            value={digit}
            onChange={(event) => setDigit(event.target.value)}
            inputMode="numeric"
            aria-label="Réponse USSD"
            placeholder="Numéro"
            className="h-12 min-w-0 flex-1 rounded-xl bg-paper/10 px-3 text-base text-paper outline-none placeholder:text-paper/50"
          />
          <button
            type="submit"
            className="press h-12 rounded-xl bg-laterite px-4 font-semibold text-ink"
          >
            Envoyer
          </button>
        </form>
      </div>
    </div>
  );
}

function ussdLines(
  step: UssdStep,
  places: Place[],
  vehicle: Vehicle,
  fromId: string | null,
  toId: string | null,
  hour: number,
  trips: SavedTrip[],
  net: NetId,
): string[] {
  if (step === "home") {
    return ["Waka Bertoua", `Reseau ${NETS[net].label}`, "", "1 Course", "2 Mes courses", "3 Changer de reseau"];
  }
  if (step === "receipts") {
    if (trips.length === 0) return ["Aucune course.", "", "0 Retour"];
    return [
      "Dernieres courses",
      ...trips.slice(0, 4).map((trip) => `${trip.from} - ${trip.to} : ${fcfa(trip.price)}`),
      "",
      "0 Retour",
    ];
  }
  if (step === "vehicle") {
    return ["Vehicule", "1 Moto", "2 Taxi jaune", "3 Berline", "", "0 Retour"];
  }
  if (step === "from" || step === "to") {
    return [
      step === "from" ? "Depart" : "Arrivee",
      ...places.map((place, index) => `${index + 1} ${place.name}`),
      "",
      "0 Retour",
    ];
  }
  const from = fromId ? placeById(fromId) : null;
  const to = toId ? placeById(toId) : null;
  if (!from || !to) return ["Course incomplete", "0 Retour"];
  const priced = quote(from, to, vehicle, hour);
  if (priced.blocked) return [priced.blocked, "", "0 Retour"];
  return [
    "Confirmer",
    `${vehicleMeta(vehicle).label}`,
    `${from.name}`,
    `vers ${to.name}`,
    `${fcfa(priced.price)} · ${formatKm(priced.km)}`,
    `${priced.minutes} min sur la route`,
    "",
    "1 Oui",
    "2 Annuler",
    "0 Retour",
  ];
}
